// "The Ice That Sailed to India" v9: shot list timed to the REAL word times of voice.wav (beats.js / captions.js come from
// align2.py), with prop inserts, diagrams and word-by-word captions in the reference style.
// The story is keyed to audio frames; video frame f = story frame f + SHIFT (the 2.37 s of silent lead-in is cut).
import { M, camFromKeys, blinkAt, idle, q, clamp, lerp } from './motion.js';
import { BEAT } from './beats.js';
import { CAPTIONS } from './captions.js';
export const FPS = 30, DECK = 0, SHIFT = 71;
export const TOTAL = 2204 - SHIFT;
export const smooth = M.smooth;
export const PLACES = {
  BOSTON: [0, 0, 0], WHARF: [0, 0, -34], CAL: [2000, 0, 0], HOLD: [4000, 0, 0], SEA: [6000, 0, 0],
  JACKET: [8000, 0, 0], WALDEN: [10000, 0, 0], CHENNAI: [12000, 0, 0], STUDIO: [14000, 0, 0],
};
const P = PLACES, W = P.WHARF, C = P.CAL, H = P.HOLD, J = P.JACKET, Wd = P.WALDEN, K = P.CHENNAI, ST = P.STUDIO;
const A = (p, x, y, z) => [p[0] + x, p[1] + y, p[2] + z];
const fr = (k) => Math.round(BEAT[k] * 30);
export const shipZ = (f) => -90 + (f - fr('may')) * 0.2; // the Tuscany at sea sails +z at 6 m/s
// stylised portrait map (x, y in 0..1) and the Tuscany's route from Boston round the Cape to Calcutta
export const MAP_SIZE = [10, 17.5], MAP_CY = 9;
export const MAP_ROUTE = [[0.31, 0.19], [0.38, 0.38], [0.42, 0.6], [0.52, 0.82], [0.66, 0.8], [0.78, 0.62], [0.9, 0.46], [0.86, 0.4]];
export const MAP_CITIES = { calcutta: [0.86, 0.4], bombay: [0.74, 0.44], madras: [0.82, 0.52] };
export const routePoint = (u) => {
  const seg = []; let tot = 0;
  for (let i = 1; i < MAP_ROUTE.length; i++) { const d = Math.hypot(MAP_ROUTE[i][0] - MAP_ROUTE[i - 1][0], MAP_ROUTE[i][1] - MAP_ROUTE[i - 1][1]); seg.push(d); tot += d; }
  let t = clamp(u) * tot;
  for (let i = 0; i < seg.length; i++) { if (t <= seg[i]) { const k = t / seg[i]; return [lerp(MAP_ROUTE[i][0], MAP_ROUTE[i + 1][0], k), lerp(MAP_ROUTE[i][1], MAP_ROUTE[i + 1][1], k)]; } t -= seg[i]; }
  return MAP_ROUTE[MAP_ROUTE.length - 1];
};

const k = (f, pos, look, fov = 40, o = {}) => ({ f, pos, look, fov, ...o });
const S = (x, y, z = 0) => A(ST, x, y, z), D = (x, y, z = 0) => A(ST, 40 + x, y, z), G = (x, y, z = 0) => A(ST, 80 + x, y, z);
const seaK = (f, dx, y, dz, ly, fov, o = {}) => k(f, [P.SEA[0] + dx, y, shipZ(f) + dz], [P.SEA[0], ly, shipZ(f) + (dz < 0 ? 6 : 3)], fov, o);
// ---------- the shot list (tag, first story frame, light, zone, camera keys) ----------
const LIST = [
  ['h_wide', 71, 'day', 'wharf', [k(71, A(W, 6.5, 2.4, 8), A(W, -0.3, 1.2, 0), 50), k(126, A(W, 4.2, 1.8, 4.8), A(W, -0.3, 1.2, 0), 46)]],
  ['h_side', fr('start') + 47, 'day', 'wharf', [k(127, A(W, -3.5, 1.3, 3.6), A(W, -0.2, 1.1, 0.2), 44, { roll: 2 })]],
  ['h_ice', fr('frozen'), 'day', 'wharf', [k(fr('frozen'), A(W, 1.3, 1.35, 1.6), A(W, 0.2, 1.1, 0), 34, { roll: -2.5 })]],
  ['h_ship', fr('ship1'), 'day', 'wharf', [k(fr('ship1'), A(W, 14, 4, -2), A(W, -2, 8, -12), 56)]],
  ['map1', fr('then1'), 'day', 'studio', [k(fr('then1'), S(-1.2, 11.4, 20), S(-1.2, 11.4), 34), k(fr('calcutta') - 2, S(-0.4, 8.2, 20), S(-0.4, 8.2), 34)]],
  ['cal_aerial', fr('calcutta'), 'golden', 'cal', [k(fr('calcutta'), A(C, 9, 5.5, -22), A(C, 0, 3.5, 4), 42)]],
  ['cal_street', fr('city'), 'golden', 'cal', [k(fr('city'), A(C, -1.5, 1.7, -8), A(C, 0.5, 1.4, 2), 44)]],
  ['cal_bishop', fr('summer'), 'golden', 'cal', [k(fr('summer'), A(C, -1.0, 3.4, -4), A(C, -4.5, 3.2, 2), 44), k(fr('bishop') + 12, A(C, -2.5, 3.1, -5), A(C, -4.5, 3.4, 2), 36, { roll: 2, ease: 'easeOut' })]],
  ['cal_thermo', fr('heat'), 'golden', 'cal', [k(fr('heat'), A(C, -1.3, 2.55, 1.35), A(C, -3.35, 2.55, 1.35), 30)]],
  ['cal_face', fr('suffocating'), 'golden', 'cal', [k(fr('suffocating'), A(C, -0.9, 3.35, 1.7), A(C, -4.5, 3.3, 2.0), 30, { roll: 3 })]],
  ['t_med', fr('frederic'), 'day', 'wharf', [k(fr('frederic'), A(W, 3, 1.5, -5.5), A(W, 0, 1.4, 0), 38)]],
  ['t_face', fr('tried'), 'day', 'wharf', [k(fr('tried'), A(W, 0.7, 1.75, -2.4), A(W, 0, 1.72, 0), 28, { roll: -2 })]],
  ['t_med2', fr('his'), 'day', 'wharf', [k(fr('his'), A(W, 3.4, 1.5, -5.2), A(W, 0, 1.4, 0), 38)]],
  ['t_puddle', fr('melted'), 'day', 'wharf', [k(fr('melted'), A(W, 0.4, 0.9, -3.2), A(W, 0, 0.12, 0.3), 36, { roll: -2 })]],
  ['t_wide', fr('dock'), 'day', 'wharf', [k(fr('dock'), A(W, -4, 1.8, -6.5), A(W, 0, 1.2, 0), 42)]],
  ['x_sacks', fr('so1'), 'day', 'wharf', [k(fr('so1'), A(W, -5, 1.7, -5), A(W, -1.5, 1.2, 0), 42)]],
  ['x_rice', fr('rice'), 'day', 'wharf', [k(fr('rice'), A(W, -3, 1.4, -3.8), A(W, -3, 0.75, 0.4), 34, { roll: -2 })]],
  ['x_chaff', fr('chaff'), 'day', 'wharf', [k(fr('chaff'), A(W, -1, 1.4, -3.8), A(W, -1, 0.75, 0.4), 34, { roll: 2 })]],
  ['x_coal', fr('coal'), 'day', 'wharf', [k(fr('coal'), A(W, 1, 1.4, -3.8), A(W, 1, 0.75, 0.4), 34, { roll: -2 })]],
  ['x_bark', fr('bark'), 'day', 'wharf', [k(fr('bark'), A(W, 3, 1.4, -3.8), A(W, 3, 0.75, 0.4), 34, { roll: 2 })]],
  ['x_saw', fr('sawdust1'), 'day', 'wharf', [k(fr('sawdust1'), A(W, 5, 1.5, -4.8), A(W, 5, 0.95, 0), 36)]],
  ['p_wide', fr('then2'), 'day', 'wharf', [k(fr('then2'), A(W, 14, 3.5, 3), A(W, -8, 2.2, -11), 50), k(fr('nothing') - 1, A(W, 10, 3.2, 0), A(W, -8, 2.4, -11), 47)]],
  ['p_deck', fr('nothing'), 'day', 'wharf', [k(fr('nothing'), A(W, -4, 3.2, -3), A(W, -8, 2.2, -12), 46)]],
  ['p_load', fr('so2'), 'day', 'wharf', [k(fr('so2'), A(W, -1.5, 3.6, -2.5), A(W, -8, 2.6, -12), 46), k(fr('winter') + 8, A(W, -3, 3.4, -4), A(W, -8, 2.6, -12), 40)]],
  ['d_wide', fr('doublewalls'), 'day', 'hold', [k(fr('doublewalls'), A(H, 3.7, 1.6, -6.4), A(H, 2.8, 1.4, -2.0), 40)]],
  ['d_wall', fr('sawdust2'), 'day', 'hold', [k(fr('sawdust2'), A(H, 2.75, 1.5, -4.6), A(H, 2.75, 1.4, -2.2), 28)]],
  ['d_ruler', fr('half1'), 'day', 'hold', [k(fr('half1'), A(H, 2.75, 1.3, -3.9), A(H, 2.73, 1.15, -2.3), 36)]],
  ['u_pump', fr('everyday'), 'day', 'hold', [k(fr('everyday'), A(H, -2.2, 1.0, -4.2), A(H, -1.2, 0.5, 0), 36, { roll: 1.7 })]],
  ['u_drip', fr('meltwater'), 'day', 'hold', [k(fr('meltwater'), A(H, -1.1, 1.15, -2.8), A(H, -1.5, 0.7, 0), 38)]],
  ['e_sea1', fr('may'), 'golden', 'sea', [seaK(fr('may'), 26, 8, -6, 2.5, 44), seaK(fr('halfworld') - 6, 16, 4.5, -5, 3, 42, { roll: -2 })]],
  ['m_world', fr('halfworld'), 'golden', 'studio', [k(fr('halfworld'), S(1.2, 7, 20), S(1.2, 7), 34), k(fr('fourmonths') - 2, S(1.5, 10, 20), S(1.5, 10), 34)]],
  ['e_sea2', fr('fourmonths'), 'golden', 'sea', [seaK(fr('fourmonths'), 14, 3.4, -4, 3, 40, { roll: -2.3 }), seaK(fr('luckily') - 2, 13, 3.3, -3, 3, 38, { roll: -2.3 })]],
  ['l_wide', fr('luckily'), 'day', 'hold', [k(fr('luckily'), A(H, 0.4, 1.7, -8), A(H, 0.5, 1.3, -0.5), 40)]],
  ['l_face', fr('unluckily'), 'day', 'hold', [k(fr('unluckily'), A(H, -0.1, 1.7, -3.2), A(H, -0.1, 1.7, -1.4), 28, { roll: 3 })]],
  ['l_half', fr('eighty2'), 'day', 'hold', [k(fr('eighty2'), A(H, -0.3, 1.2, -4.6), A(H, 0.3, 0.9, -1.0), 36, { roll: 2.3 })]],
  ['l_puddle', fr('did_not') + 6, 'day', 'hold', [k(fr('did_not') + 6, A(H, -0.9, 0.9, -1.7), A(H, -0.9, 0.1, 0.1), 34)]],
  ['j_kid1', fr('sowhy'), 'night', 'jacket', [k(fr('sowhy'), A(J, 0.8, 1.2, -3.4), A(J, 0, 1.05, 0), 34)]],
  ['j_diag1', fr('sawdust3'), 'night', 'studio', [k(fr('sawdust3'), D(0, 12.3, 20), D(0, 12.3), 30), k(fr('sawdust3') + 70, D(0, 12.2, 17), D(0, 12.2), 28)]],
  ['j_diag2', fr('airis'), 'night', 'studio', [k(fr('airis'), D(0, 6.0, 20), D(0, 6.0), 30), k(fr('airis') + 50, D(0, 4.3, 16), D(0, 4.3), 26)]],
  ['j_kid2', fr('its'), 'night', 'jacket', [k(fr('its'), A(J, 0.3, 1.3, -2.6), A(J, 0, 1.2, 0), 34, { roll: -2 })]],
  ['j_wrap', fr('wrapped'), 'night', 'jacket', [k(fr('wrapped'), A(J, 13, 4.5, -9), A(J, 4.5, 0.9, 3), 44, { roll: 2 })]],
  ['k_tables', fr('september'), 'golden', 'cal', [k(fr('september'), A(C, -1.6, 2.0, -1.8), A(C, 0.6, 1.2, 6.0), 44, { roll: 2 })]],
  ['k_glass', fr('glittered'), 'golden', 'cal', [k(fr('glittered'), A(C, 0.9, 1.1, 5.1), A(C, 0.9, 0.95, 6.1), 26)]],
  ['s_sea3', fr('soon'), 'golden', 'sea', [seaK(fr('soon'), 14, 5, -8, 3, 42), seaK(fr('icehouses') - 2, 10, 3.6, -5, 3, 38, { roll: 2 })]],
  ['i_house', fr('icehouses'), 'golden', 'cal', [k(fr('icehouses'), A(C, 14, 2.8, -19), A(C, 21, 3, -10), 44)]],
  ['i_map', fr('bombay') - 10, 'golden', 'studio', [k(fr('bombay') - 10, S(2.7, 9.4, 16), S(2.7, 9.4), 28)]],
  ['c_wide', fr('chennai'), 'golden', 'chennai', [k(fr('chennai'), A(K, 22, 6, -34), A(K, 0, 3.5, 0), 40), k(fr('chennai') + 35, A(K, 16, 5, -26), A(K, 0, 3.8, 0), 38)]],
  ['g_chart', fr('within'), 'golden', 'studio', [k(fr('within'), G(0, 8.3, 19), G(0, 8.3), 40), k(fr('within') + 95, G(0, 8.6, 17), G(0, 8.6), 36)]],
  ['w_thoreau', fr('thoreau'), 'golden', 'walden', [k(fr('thoreau'), A(Wd, 17.5, 3.2, -9.5), A(Wd, 12, 1.3, -2.5), 36)]],
  ['w_face', fr('noticed'), 'golden', 'walden', [k(fr('noticed'), A(Wd, 14, 1.85, -4.8), A(Wd, 12, 1.75, -2.5), 28)]],
  ['w_pull', fr('water'), 'golden', 'walden', [k(fr('water'), A(Wd, 14, 3.2, -8), A(Wd, 16, 1.0, 0), 40), k(2203, A(Wd, 2, 6, -20), A(Wd, 36, 1.0, 0), 52)]],
];
export const SHOTS = LIST.map(([tag, a, light, zone], i) => ({ id: i + 1, tag, a, b: i + 1 < LIST.length ? LIST[i + 1][1] - 1 : 2203, light, zone }));
const CAMS = {};
LIST.forEach(([, , , , keys], i) => { CAMS[i + 1] = keys; });
// a key with ease 'easeOut' is a burst: hold the previous pose, then arrive over `dur` frames
for (const id of Object.keys(CAMS)) {
  const K0 = CAMS[id], out = [K0[0]];
  for (let i = 1; i < K0.length; i++) { const prev = out[out.length - 1], kk = K0[i];
    if (kk.ease === 'easeOut') { const f0 = Math.max(prev.f, kk.f - (kk.dur || 12)); if (f0 > prev.f) out.push({ ...prev, f: f0, ease: 'smooth' }); } out.push(kk); }
  CAMS[id] = out;
}
const _shotAt = (f) => SHOTS.find((s) => f >= s.a && f <= s.b) || SHOTS[SHOTS.length - 1];

// ---------- lights (eye-comfort 2.5D bible: warm cream whites, lifted shadows, saturated colour) ----------
export const LIGHTS = {
  day: { az: 140, el: 46, sky: '#dbe7f7', ground: '#8c7a6b', hemi: 1.2, sun: '#ffe6b8', sunI: 2.4, fog: '#e4eaf2', fogNear: 140, fogFar: 1000,
    skyTop: '#3f86e6', skyHor: '#dce9f5', sat: 1.34, gain: '#fff6e6', lift: '#100c18', waterDeep: '#2c6c8c', waterShal: '#5aaec4', glint: '#fff3dc', vig: 0.2, shadowExt: 22 },
  golden: { az: 8, el: 9, sky: '#8d82c6', ground: '#5a4a8e', hemi: 1.05, sun: '#ffb36b', sunI: 2.8, fog: '#efb78f', fogNear: 110, fogFar: 900,
    skyTop: '#6a64c0', skyHor: '#ffbf78', sunDisc: '#ffe3b0', sunSize: 0.0035, sat: 1.34, gain: '#ffeccc', lift: '#201838', waterDeep: '#3d5a86', waterShal: '#d99a6e', glint: '#ffd28a', vig: 0.26, shadowExt: 22 },
  night: { az: 200, el: 30, sky: '#5a6fa8', ground: '#3a3f72', hemi: 1.1, sun: '#9fb8ff', sunI: 1.5, fog: '#34437a', fogNear: 60, fogFar: 600,
    skyTop: '#1b2a5c', skyHor: '#4a5f9c', sat: 1.28, gain: '#e8eeff', lift: '#0f1538', waterDeep: '#1c2c58', waterShal: '#3c5a90', glint: '#a8c4ff', vig: 0.3, shadowExt: 18 },
};
export const lightFor = (S0) => ({ ...LIGHTS[S0.light] });

// ---------- camera ----------
const KICKS = [{ f: fr('melted'), a: 0.05 }, { f: fr('won'), a: 0.05 }, { f: fr('eighty2'), a: 0.06 }, { f: fr('its'), a: 0.04 }, { f: fr('mingling'), a: 0.04 }];
const pulseFrames = [];
SHOTS.forEach((s, i) => { if (i && SHOTS[i - 1].zone !== s.zone) pulseFrames.push(s.a); });
const _camAt = (f) => {
  const S0 = _shotAt(f), c = camFromKeys(CAMS[S0.id], f, { creep: 0.0012, kicks: KICKS });
  c.flash = 0;
  for (const p of pulseFrames) if (f >= p && f < p + 4) c.flash = 0.28 * (1 - (f - p) / 4);
  return c;
};
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
const CINF = { t_face: 14, cal_face: 14, l_face: 14, w_face: 14, h_ice: 12, x_rice: 12, x_chaff: 12, x_coal: 12, x_bark: 12, x_saw: 10, t_puddle: 12, d_wall: 8, d_ruler: 8, u_drip: 12, l_puddle: 12,
  t_med: 10, t_med2: 10, x_sacks: 10, u_pump: 10, l_wide: 10, l_half: 12, j_kid1: 11, j_kid2: 11, k_tables: 8, k_glass: 12, cal_street: 8, cal_thermo: 10, w_thoreau: 7, h_side: 10 };
const _dofAt = (f) => { const S0 = _shotAt(f), C0 = _camAt(f); return { focus: dist(C0.pos, C0.look), cinf: CINF[S0.tag] || 0 }; };

// ---------- world state ----------
const _worldAt = (f) => {
  const S0 = _shotAt(f), tag = S0.tag;
  return {
    id: S0.id, tag, hero: tag.startsWith('h_'),
    seaShip: tag.startsWith('e_') || tag.startsWith('s_') ? [P.SEA[0], 0.1 * Math.sin(f / 30 * 1.6), shipZ(f)] : null,
    holdTop: f < fr('eighty2'), deckIce: f >= fr('so2'),
    thermo: lerp(0.3, 1.0, clamp((f - fr('heat')) / 40)),
    mapU: f < fr('calcutta') ? 0.5 * clamp((f - fr('then1')) / (fr('calcutta') - fr('then1'))) : f < fr('fourmonths') ? 0.5 + 0.5 * clamp((f - fr('halfworld')) / (fr('fourmonths') - fr('halfworld'))) : 1,
    pins: f >= fr('bombay') + 18 ? 3 : f >= fr('bombay') ? 2 : f >= fr('icehouses') + 25 ? 1 : 0,
    bar1: clamp((f - (fr('within') + 10)) / 30), bar2: clamp((f - fr('delivering')) / (fr('ayear') + 15 - fr('delivering'))),
  };
};

// ---------- captions ----------
export const captionAt = (f) => { const s = f + SHIFT; for (const [a, b, t] of CAPTIONS) if (s >= a && s < b) return t; return ''; };

// ---------- actors (2D cards) ----------
const R = (T, who, o, pos, extra = {}) => ({ key: who + JSON.stringify(o), draw: (p) => T.romanFront(p, who, o), x: pos[0], y: pos[1], z: pos[2], ...extra });
const FOLK = ['calA', 'calB', 'calC', 'calD', 'calE', 'calF'];
const _actorsAt = (f, T) => {
  const S0 = _shotAt(f), tag = S0.tag, out = [], tint = S0.light === 'golden' ? '#ffe2c8' : S0.light === 'night' ? '#c9d6ff' : '#ffffff';
  const t = f / 30, blink = (s) => blinkAt(f, s);
  const worker = (i, pos, expr = 'neutral', step) => out.push(R(T, ['cutA', 'cutB', 'cutC'][i % 3], { seed: 10 + i, expr, step: step ?? q((t * 1.6 + i * 0.13) % 1, 2), blink: blink(10 + i), ...idle(f, i) }, pos, { tint }));
  const standing = (i, who, pos, expr, o = {}, ex = {}) => out.push(R(T, who, { seed: 10 + i, expr, L: 'hang', R: 'hang', blink: blink(10 + i), ...idle(f, i), ...o }, pos, { tint, ...ex }));
  const haul = (n) => { for (let i = 0; i < n; i++) { const u = (t * 0.1 + i / n) % 1; worker(i, [lerp(W[0] + 7, W[0] - 4, u), 0, lerp(W[2] + 9, W[2] - 5, u)], 'grin'); } };
  const tudor = (pos, expr, o = {}) => standing(2, 'tudor', pos, expr, o);
  const crowd = (n) => { for (let i = 0; i < n; i++) { const x = C[0] + (((i * 37) % 70) / 10 - 3.5), z = C[2] - 14 + i * 1.7 + ((i * 7) % 5) * 0.2;
    out.push(R(T, FOLK[i % 6], { seed: 30 + i, expr: i % 2 ? 'pained' : 'dazed', L: 'hang', R: 'wave', wv: f * 0.45 + i, blink: blink(30 + i), ...idle(f, i) }, [x, 0, z], { tint })); } };
  const bishop = (expr) => out.push(R(T, 'bishop', { seed: 5, expr, L: 'hang', R: 'wave', wv: f * 0.4, blink: blink(5), ...idle(f, 5) }, A(C, -4.5, 2.0, 2.0), { tint, ground: 2.0 }));
  const lost = f >= fr('unluckily') - 2;
  if (tag === 'h_wide' || tag === 'h_side' || tag === 'h_ice') {
    [[-2.0, 0.3], [2.4, -0.2]].forEach(([dx, dz], i) => standing(40 + i, ['cutA', 'cutB'][i], A(W, dx, 0, dz), 'grin'));
    haul(4);
  } else if (tag === 'h_ship') haul(3);
  else if (tag === 'cal_aerial' || tag === 'cal_street') crowd(16);
  else if (tag === 'cal_bishop') { crowd(8); bishop(f < fr('bishop') + 6 ? 'neutral' : 'pained'); }
  else if (tag === 'cal_thermo') bishop('pained');
  else if (tag === 'cal_face') bishop('pained');
  else if (tag === 't_med' || tag === 't_face') tudor(A(W, 0, 0, 0), tag === 't_face' ? 'wide' : 'stern');
  else if (tag === 't_med2') { haul(2); tudor(A(W, 0, 0, 0), f < fr('melted') - 2 ? 'stern' : 'shock'); }
  else if (tag === 't_puddle' || tag === 't_wide') { haul(2); tudor(A(W, 0, 0, 0), 'shock'); }
  else if (tag.startsWith('x_')) {
    const px = { x_sacks: -3, x_rice: -3, x_chaff: -1, x_coal: 1, x_bark: 3, x_saw: 5 }[tag];
    tudor(A(W, px, 0, 1.9), f < fr('sawdust1') - 2 ? 'nervous' : 'grin');
    standing(50, 'cutA', A(W, px - 1.8, 0, 1.4), 'grin');
  } else if (tag === 'p_wide') { haul(6); tudor(A(W, -2.5, 0, 1), 'smile'); }
  else if (tag === 'p_deck') haul(2);
  else if (tag === 'p_load') { haul(5); tudor(A(W, -4, 0, 1), 'smile'); }
  else if (tag === 'u_pump' || tag === 'u_drip') [-0.5, 0.7].forEach((dz, i) => { const up = Math.sin(f * 0.33 + i * 1.6) > 0;
    out.push(R(T, 'sailA', { seed: 60 + i, expr: 'neutral', L: up ? 'lift' : 'hang', R: up ? 'hang' : 'lift', blink: blink(60 + i) }, [H[0] - 1.45, 0, H[2] + dz], { tint })); });
  else if (tag.startsWith('e_') || tag.startsWith('s_')) {
    const sz = shipZ(f), bob = 0.1 * Math.sin(t * 1.6);
    [[-0.8, -3], [1.0, 1.5], [-1.2, 6.5]].forEach(([lx, lz], i) => standing(70 + i, 'sailA', [P.SEA[0] + lx, 1.8 + bob, sz + lz], 'neutral', {}, { ground: 1.8 }));
  } else if (tag.startsWith('l_')) {
    tudor(A(H, -0.1, 0, -1.4), !lost ? 'relief' : f < fr('unluckily') + 12 ? 'shock' : 'pained');
    standing(62, 'sailA', A(H, -1.3, 0, -2.0), lost ? 'dazed' : 'smile');
  } else if (tag === 'j_kid1' || tag === 'j_kid2') standing(80, 'kid', [J[0], 0, J[2]], tag === 'j_kid1' ? 'wide' : f < fr('its') + 20 ? 'laugh' : 'grin', {}, { s: 0.82 });
  else if (tag === 'k_tables') [[-1.3, 5.1], [0.2, 4.9], [1.5, 5.2], [-1.1, 7.0], [0.4, 7.2], [1.6, 6.9]].forEach(([dx, dz], i) =>
    standing(90 + i, FOLK[i], A(C, dx, 0, dz), ['smile', 'grin', 'relief', 'smile_closed', 'laugh', 'smile'][i], { R: i % 2 ? 'up' : 'hang' }));
  else if (tag === 'w_thoreau' || tag === 'w_face' || tag === 'w_pull') {
    standing(95, 'thoreau', A(Wd, 12, 0, -2.5), tag === 'w_face' ? 'wide' : tag === 'w_pull' ? 'smile' : 'smile_closed');
    for (let i = 0; i < 5; i++) worker(i, A(Wd, 5 + i * 2.2, 0, 4 + ((i * 7) % 5) * 0.6), 'neutral', 0);
  }
  return out;
};

// ---------- 2D effects ----------
const FX = (key, draw, pos, s, extra = {}) => ({ key, draw, x: pos[0], y: pos[1], z: pos[2], s, blob: false, shadow: false, order: 5, ...extra });
const _fxAt = (f, T) => {
  const S0 = _shotAt(f), tag = S0.tag, out = [], tm = fr('melted');
  if (f >= tm && f < fr('so1') + 40 && (tag === 't_puddle' || tag === 't_wide' || tag === 't_med2')) {
    const kk = clamp((f - tm) / 36), s = 0.6 + 1.4 * M.smooth(kk);
    out.push(FX('puddle' + q(kk, 1), (p) => { p.ell(300, 700, 140, 40, '#6f97c6', 0); p.ell(250, 690, 90, 20, '#a9c9ea', 0); }, [W[0], 0.1, W[2] + 0.7], s));
  }
  if ((tag === 't_puddle' || tag === 't_med2') && f >= tm && f < tm + 13) { const k2 = q((f - tm) / 13, 2); out.push(FX('burstm' + k2, (p) => T.fxBurst(p, k2, '#cfe9ff'), [W[0] + 0.5, 1.4, W[2] - 0.1], 1.1)); }
  if (tag === 'x_saw' && f >= fr('won') && f < fr('won') + 13) { const k2 = q((f - fr('won')) / 13, 2); out.push(FX('bursts' + k2, (p) => T.fxBurst(p, k2, '#ffe9a0'), [W[0] + 5, 1.3, W[2] - 0.2], 1.3)); }
  if (tag === 'l_half' && f >= fr('eighty2') && f < fr('eighty2') + 19) { const k2 = q((f - fr('eighty2')) / 19, 2); out.push(FX('splashh' + k2, (p) => { p.g.translate(0, 130); p.g.scale(0.75, 0.75); T.fxSplash(p, k2); }, A(H, 0.2, 0.05, -0.6), 1.4)); }
  if (tag === 'u_drip' || tag === 'l_puddle') { const u = (f * 0.05) % 1; out.push(FX('drip' + q(u, 10), (p) => p.ell(300, 500, 18, 28, '#8fc4e8', 0), A(H, -1.1, 0.95 - 0.8 * u * u, 0.1), 0.35)); }
  if (tag === 'cal_face' || tag === 'cal_thermo') { const u = (f * 0.04) % 1; out.push(FX('sweat' + q(u, 10), (p) => p.ell(300, 500, 20, 32, '#9ed0f0', 0), A(C, -4.2, 3.9 - 0.6 * u, 1.6), 0.32)); }
  if (tag === 'j_kid2' && f >= fr('its')) for (let i = 0; i < 6; i++) { const u = q(((f - fr('its')) * 0.02 + i / 6) % 1, 2), a = i * 1.05;
    out.push(FX('puff' + u, (p) => T.fxPuff(p, u), [J[0] + 0.55 * Math.cos(a), 1.0 + 0.3 * Math.sin(a * 2), J[2] + 0.25 * Math.sin(a)], 0.4)); }
  if (tag === 'k_tables' || tag === 'k_glass') { const u = q((f * 0.03) % 1, 2); out.push(FX('stars' + u, (p) => T.fxStars(p, u), A(C, tag === 'k_glass' ? 0.9 : 0, tag === 'k_glass' ? 1.25 : 1.6, 6), 0.9)); }
  if (S0.light === 'day' && !tag.startsWith('map')) { const C0 = _camAt(f); for (let i = 0; i < 9; i++) { const a = f * 0.02 + i * 2.1, d = 2.2 + (i % 4) * 0.7;
    const x = C0.pos[0] + (C0.look[0] - C0.pos[0]) * d / 4 + Math.sin(a) * 0.9, y = C0.pos[1] + 0.2 + (i % 3) * 0.35 + Math.sin(a * 1.3) * 0.15, z = C0.pos[2] + (C0.look[2] - C0.pos[2]) * d / 4 + Math.cos(a * 0.8) * 0.9;
    out.push(FX('mote' + (i % 3), (p) => p.ell(300, 500, 30, 30, 'rgba(255,243,220,0.55)', 0), [x, y, z], 0.18)); } }
  return out;
};

// ---------- public API: everything takes a VIDEO frame ----------
export const shotAt = (f) => _shotAt(f + SHIFT);
export const camAt = (f) => _camAt(f + SHIFT);
export const dofAt = (f) => _dofAt(f + SHIFT);
export const worldAt = (f) => _worldAt(f + SHIFT);
export const actorsAt = (f, T) => _actorsAt(f + SHIFT, T);
export const fxAt = (f, T) => _fxAt(f + SHIFT, T);
