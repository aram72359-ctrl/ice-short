// Painted textures for "The Ice That Sailed to India" (our own, deterministic Canvas2D, no dependencies).
const rng = (seed) => { let s = seed >>> 0 || 1; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); };
const cv = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return [c, c.getContext('2d')]; };
/** run draw(ox, oy) at the 9 wrapped offsets so a texture tiles without seams */
const wrap = (W, H, draw) => { for (const ox of [-W, 0, W]) for (const oy of [-H, 0, H]) draw(ox, oy); };

export function snow(seed = 21) {
  const W = 512, [c, g] = cv(W, W), r = rng(seed);
  g.fillStyle = '#ebeef0'; g.fillRect(0, 0, W, W);
  for (let i = 0; i < 30; i++) { const x = r() * W, y = r() * W, rad = 40 + r() * 90;
    wrap(W, W, (ox, oy) => { const gr = g.createRadialGradient(x + ox, y + oy, 0, x + ox, y + oy, rad); gr.addColorStop(0, 'rgba(165,192,226,0.24)'); gr.addColorStop(1, 'rgba(165,192,226,0)'); g.fillStyle = gr; g.fillRect(x + ox - rad, y + oy - rad, rad * 2, rad * 2); }); }
  g.lineCap = 'round';
  for (let i = 0; i < 46; i++) { const x = r() * W, y = r() * W, l = 30 + r() * 70, a = 0.12 + r() * 0.14, lw = 1.5 + r() * 2, bend = 6 + r() * 8;
    wrap(W, W, (ox, oy) => { g.strokeStyle = `rgba(140,172,210,${a})`; g.lineWidth = lw; g.beginPath(); g.moveTo(x + ox, y + oy); g.quadraticCurveTo(x + ox + l / 2, y + oy - bend, x + ox + l, y + oy); g.stroke(); }); }
  for (let i = 0; i < 260; i++) { const x = r() * W, y = r() * W, s = 0.8 + r() * 1.6, wht = r() < 0.7;
    wrap(W, W, (ox, oy) => { g.fillStyle = wht ? 'rgba(255,248,232,0.9)' : 'rgba(150,185,225,0.55)'; g.beginPath(); g.arc(x + ox, y + oy, s, 0, 7); g.fill(); }); }
  return c;
}
export function ice(seed = 22) {
  const W = 256, [c, g] = cv(W, W), r = rng(seed);
  const gr = g.createLinearGradient(0, 0, W, W); gr.addColorStop(0, '#dcf4fc'); gr.addColorStop(0.5, '#b6dff0'); gr.addColorStop(1, '#94c6e2');
  g.fillStyle = gr; g.fillRect(0, 0, W, W);
  for (let i = 0; i < 8; i++) { let x = r() * W, y = r() * W; g.beginPath(); g.moveTo(x, y); for (let k = 0; k < 5; k++) { x += (r() - 0.5) * 70; y += (r() - 0.5) * 70; g.lineTo(x, y); }
    g.strokeStyle = r() < 0.5 ? 'rgba(255,255,255,0.6)' : 'rgba(60,110,155,0.3)'; g.lineWidth = 1 + r() * 1.6; g.stroke(); }
  for (let i = 0; i < 34; i++) { g.beginPath(); g.arc(r() * W, r() * W, 1 + r() * 3.5, 0, 7); g.fillStyle = `rgba(255,255,255,${0.25 + r() * 0.3})`; g.fill(); }
  const sh = g.createLinearGradient(0, 0, W, 0); sh.addColorStop(0, 'rgba(255,255,255,0)'); sh.addColorStop(0.5, 'rgba(255,255,255,0.2)'); sh.addColorStop(1, 'rgba(255,255,255,0)');
  g.save(); g.translate(W / 2, W / 2); g.rotate(-0.6); g.fillStyle = sh; g.fillRect(-200, -34, 400, 68); g.restore();
  g.lineWidth = 16; g.strokeStyle = 'rgba(240,252,255,0.8)'; g.strokeRect(0, 0, W, W);
  return c;
}
export function pond(seed = 23) {
  const W = 512, [c, g] = cv(W, W), r = rng(seed);
  g.fillStyle = '#b9dcec'; g.fillRect(0, 0, W, W);
  for (let i = 0; i < 18; i++) { const x = r() * W, y = r() * W, rad = 50 + r() * 100, light = r() < 0.5;
    wrap(W, W, (ox, oy) => { const gr = g.createRadialGradient(x + ox, y + oy, 0, x + ox, y + oy, rad); gr.addColorStop(0, light ? 'rgba(235,250,255,0.4)' : 'rgba(110,160,200,0.28)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(x + ox - rad, y + oy - rad, rad * 2, rad * 2); }); }
  for (let i = 0; i < 22; i++) { const pts = [[r() * W, r() * W]]; for (let k = 0; k < 6; k++) { const p = pts[k]; pts.push([p[0] + (r() - 0.5) * 120, p[1] + (r() - 0.5) * 120]); }
    const dark = r() < 0.6, lw = 1 + r() * 1.8;
    wrap(W, W, (ox, oy) => { g.beginPath(); pts.forEach((p, k) => (k ? g.lineTo(p[0] + ox, p[1] + oy) : g.moveTo(p[0] + ox, p[1] + oy))); g.strokeStyle = dark ? 'rgba(70,120,165,0.45)' : 'rgba(255,255,255,0.7)'; g.lineWidth = lw; g.stroke(); }); }
  return c;
}
export function hull(seed = 24) {
  const W = 256, [c, g] = cv(W, W), r = rng(seed), rows = 6, h = W / rows;
  for (let i = 0; i < rows; i++) {
    const l = 30 + r() * 8; g.fillStyle = `hsl(222,38%,${l}%)`; g.fillRect(0, i * h, W, h);
    const gr = g.createLinearGradient(0, i * h, 0, (i + 1) * h); gr.addColorStop(0, 'rgba(255,255,255,0.1)'); gr.addColorStop(1, 'rgba(0,0,20,0.18)'); g.fillStyle = gr; g.fillRect(0, i * h, W, h);
    g.strokeStyle = 'rgba(8,14,34,0.6)'; g.lineWidth = 3; g.beginPath(); g.moveTo(0, i * h); g.lineTo(W, i * h); g.stroke();
    const jx = r() * W; g.beginPath(); g.moveTo(jx, i * h); g.lineTo(jx, (i + 1) * h); g.stroke();
    for (let k = 0; k < 4; k++) { g.strokeStyle = 'rgba(180,200,240,0.12)'; g.lineWidth = 1; const y = i * h + 6 + r() * (h - 12); g.beginPath(); g.moveTo(r() * 60, y); g.lineTo(120 + r() * 136, y + (r() - 0.5) * 3); g.stroke(); }
    g.fillStyle = 'rgba(210,220,240,0.35)'; for (const nx of [jx - 6, jx + 6]) { g.beginPath(); g.arc(nx, i * h + h / 2, 1.5, 0, 7); g.fill(); }
  }
  return c;
}
export function sail(seed = 25) {
  const W = 512, [c, g] = cv(W, W), r = rng(seed);
  const gr = g.createLinearGradient(0, 0, 0, W); gr.addColorStop(0, '#f4ecd4'); gr.addColorStop(1, '#e2d3ae'); g.fillStyle = gr; g.fillRect(0, 0, W, W);
  g.strokeStyle = 'rgba(120,100,60,0.07)'; g.lineWidth = 1; for (let y = 0; y < W; y += 4) { g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }
  for (let i = 1; i < 5; i++) { const x = (i * W) / 5; g.strokeStyle = 'rgba(110,90,55,0.5)'; g.lineWidth = 2; g.beginPath(); g.moveTo(x, 0); g.lineTo(x, W); g.stroke();
    g.setLineDash([6, 5]); g.strokeStyle = 'rgba(90,70,40,0.55)'; g.lineWidth = 1.2; for (const dx of [-5, 5]) { g.beginPath(); g.moveTo(x + dx, 0); g.lineTo(x + dx, W); g.stroke(); } g.setLineDash([]); }
  for (const y of [W * 0.3, W * 0.62]) { g.fillStyle = 'rgba(120,95,55,0.22)'; g.fillRect(0, y - 6, W, 12); for (let x = 20; x < W; x += 36) { g.fillStyle = 'rgba(80,60,30,0.6)'; g.beginPath(); g.arc(x, y, 3, 0, 7); g.fill(); } }
  for (let i = 0; i < 3; i++) { const x = 30 + r() * 380, y = 30 + r() * 380, w = 40 + r() * 50, hh = 34 + r() * 40; g.fillStyle = `rgba(${200 + r() * 25},${180 + r() * 20},${140 + r() * 20},0.7)`; g.fillRect(x, y, w, hh); g.strokeStyle = 'rgba(90,70,40,0.6)'; g.setLineDash([4, 3]); g.strokeRect(x + 3, y + 3, w - 6, hh - 6); g.setLineDash([]); }
  for (let i = 0; i < 14; i++) { const x = r() * W, y = r() * W, rad = 14 + r() * 36; const rg = g.createRadialGradient(x, y, 0, x, y, rad); rg.addColorStop(0, 'rgba(150,120,70,0.16)'); rg.addColorStop(1, 'rgba(150,120,70,0)'); g.fillStyle = rg; g.fillRect(x - rad, y - rad, rad * 2, rad * 2); }
  g.strokeStyle = '#b39a6c'; g.lineWidth = 16; g.strokeRect(0, 0, W, W);
  return c;
}
export function sand(seed = 26) {
  const W = 512, [c, g] = cv(W, W), r = rng(seed);
  g.fillStyle = '#dcc592'; g.fillRect(0, 0, W, W);
  for (let i = 0; i < 24; i++) { const x = r() * W, y = r() * W, rad = 40 + r() * 80, dark = r() < 0.5;
    wrap(W, W, (ox, oy) => { const gr = g.createRadialGradient(x + ox, y + oy, 0, x + ox, y + oy, rad); gr.addColorStop(0, dark ? 'rgba(170,135,85,0.25)' : 'rgba(245,225,170,0.3)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(x + ox - rad, y + oy - rad, rad * 2, rad * 2); }); }
  g.lineCap = 'round';
  for (let i = 0; i < 60; i++) { const x = r() * W, y = r() * W, l = 40 + r() * 80, light = r() < 0.5, lw = 1.5 + r() * 1.5, bend = 5 + r() * 6;
    wrap(W, W, (ox, oy) => { g.strokeStyle = light ? 'rgba(250,236,190,0.5)' : 'rgba(160,125,80,0.32)'; g.lineWidth = lw; g.beginPath(); g.moveTo(x + ox, y + oy); g.quadraticCurveTo(x + ox + l / 2, y + oy + bend, x + ox + l, y + oy); g.stroke(); }); }
  for (let i = 0; i < 220; i++) { const x = r() * W, y = r() * W, s = 0.8 + r() * 2, col = ['#a98e65', '#c8ac7c', '#8b7550', '#efdcb0'][(r() * 4) | 0];
    wrap(W, W, (ox, oy) => { g.fillStyle = col; g.beginPath(); g.ellipse(x + ox, y + oy, s * 1.3, s, 0, 0, 7); g.fill(); }); }
  return c;
}
export function cobble(seed = 27) {
  const W = 512, [c, g] = cv(W, W), r = rng(seed); g.fillStyle = '#5e4e3d'; g.fillRect(0, 0, W, W);
  const rh = 64; for (let row = 0; row < W / rh; row++) { let x = -((row % 2) * 40); while (x < W) { const w = 60 + r() * 40, l = 56 + r() * 18, hue = 30 + r() * 10;
    g.fillStyle = `hsl(${hue},${14 + r() * 10}%,${l}%)`; g.beginPath(); g.roundRect(x + 3, row * rh + 3, w - 6, rh - 6, 14); g.fill();
    g.fillStyle = 'rgba(255,245,220,0.22)'; g.beginPath(); g.roundRect(x + 6, row * rh + 5, w - 12, 10, 6); g.fill();
    g.fillStyle = 'rgba(40,28,16,0.18)'; g.beginPath(); g.roundRect(x + 6, row * rh + rh - 16, w - 12, 10, 6); g.fill(); x += w; } }
  return c;
}
export function sawdust(seed = 28) {
  const W = 256, [c, g] = cv(W, W), r = rng(seed); g.fillStyle = '#e8cb8f'; g.fillRect(0, 0, W, W);
  for (let i = 0; i < 520; i++) { const x = r() * W, y = r() * W, w = 2 + r() * 5, h = 1 + r() * 2, a = r() * 3.14, col = ['#f4deaa', '#c9a56a', '#b58a4e', '#dcb978', '#9d7a44'][(r() * 5) | 0];
    wrap(W, W, (ox, oy) => { g.save(); g.translate(x + ox, y + oy); g.rotate(a); g.fillStyle = col; g.fillRect(-w / 2, -h / 2, w, h); g.restore(); }); }
  return c;
}
export function quilt(seed = 29) {
  const W = 256, [c, g] = cv(W, W); g.fillStyle = '#f2902f'; g.fillRect(0, 0, W, W);
  for (let i = 0; i < 4; i++) { const y = i * 64; const gr = g.createLinearGradient(0, y, 0, y + 64); gr.addColorStop(0, 'rgba(255,214,150,0.55)'); gr.addColorStop(0.5, 'rgba(255,170,70,0)'); gr.addColorStop(1, 'rgba(150,70,0,0.4)'); g.fillStyle = gr; g.fillRect(0, y, W, 64);
    g.strokeStyle = 'rgba(120,55,0,0.8)'; g.lineWidth = 3; g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); g.setLineDash([5, 4]); g.strokeStyle = 'rgba(255,225,170,0.6)'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(0, y + 5); g.lineTo(W, y + 5); g.stroke(); g.setLineDash([]); }
  for (let x = 0; x < W; x += 64) { g.strokeStyle = 'rgba(120,55,0,0.35)'; g.lineWidth = 2; g.beginPath(); g.moveTo(x, 0); g.lineTo(x, W); g.stroke(); }
  return c;
}
export function tiles(seed = 30) {
  const W = 256, [c, g] = cv(W, W), r = rng(seed), th = 32;
  g.fillStyle = '#7a3a1e'; g.fillRect(0, 0, W, W);
  for (let row = 0; row < 8; row++) for (let col = -1; col < 9; col++) { const x = col * 32 + (row % 2) * 16, y = row * th;
    g.beginPath(); g.moveTo(x, y); g.lineTo(x + 32, y); g.lineTo(x + 32, y + 20); g.arc(x + 16, y + 20, 16, 0, Math.PI); g.closePath();
    g.fillStyle = `hsl(${14 + r() * 8},${52 + r() * 12}%,${40 + r() * 10}%)`; g.fill(); g.strokeStyle = 'rgba(60,24,10,0.7)'; g.lineWidth = 2; g.stroke();
    g.fillStyle = 'rgba(255,200,150,0.18)'; g.fillRect(x + 4, y + 2, 24, 4); }
  return c;
}
export function stripes(seed = 31) {
  const W = 256, [c, g] = cv(W, 128); for (let i = 0; i < 8; i++) { g.fillStyle = i % 2 ? '#f3eadb' : '#c43d34'; g.fillRect(i * 32, 0, 32, 128); }
  const gr = g.createLinearGradient(0, 0, 0, 128); gr.addColorStop(0, 'rgba(255,255,255,0.12)'); gr.addColorStop(1, 'rgba(0,0,0,0.18)'); g.fillStyle = gr; g.fillRect(0, 0, W, 128); return c;
}
export function flag() {
  const [c, g] = cv(260, 150); for (let i = 0; i < 13; i++) { g.fillStyle = i % 2 ? '#f6f4ef' : '#b8262d'; g.fillRect(0, (i * 150) / 13, 260, 150 / 13 + 1); }
  g.fillStyle = '#26356f'; g.fillRect(0, 0, 108, 81); g.fillStyle = '#fff';
  for (let y = 0; y < 4; y++) for (let x = 0; x < 5; x++) { g.beginPath(); g.arc(14 + x * 20 + (y % 2) * 9, 14 + y * 17, 3.2, 0, 7); g.fill(); }
  return c;
}
