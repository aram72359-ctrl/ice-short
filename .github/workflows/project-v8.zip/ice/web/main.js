import * as THREE from './lib/three.module.js';
import * as T from './toon.js';
import * as P from './paint.js';
import * as P2 from './paint2.js';
import { SHOTS, TOTAL, shotAt, camAt, dofAt, LIGHTS, lightFor, actorsAt, worldAt, fxAt, PLACES } from './story.js';

const W = 1080, H = 1920;
const canvas = document.getElementById('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, preserveDrawingBuffer: true });
renderer.setPixelRatio(1); renderer.setSize(W, H, false);
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.NoToneMapping;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(40, W / H, 0.08, 1500);
const rx = (a) => a * Math.PI / 180;

// ---------- materials ----------
const grad = (() => { const d = new Uint8Array([90, 90, 90, 255, 255, 255, 255, 255]); const t = new THREE.DataTexture(d, 2, 1); t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true; return t; })();
const toon = (opts) => new THREE.MeshToonMaterial({ gradientMap: grad, ...opts });
const texM = (c, rx_ = 1, ry_ = 1, color = '#ffffff') => toon({ map: P.tex(c, rx_, ry_), color });
const M = {
  plank: texM(P.planks(1), 1, 6), beam: texM(P.beam(2), 1, 2), beamDark: texM(P.beam(3, [28, 36, 30]), 1, 2),
  rot: texM(P.rotten(4), 1, 1), rotB: texM(P.rotten(14), 1, 1),
  stone: texM(P.stone(4), 1, 1), stoneMoss: texM(P.mossy(P.stone(4), 5, 1.2), 1, 1),
  grass: texM(P.grass(6), 40, 40), dirt: texM(P.dirt(7), 6, 30), plaster: texM(P.plaster(8), 1, 1), plaster2: texM(P.plaster(18, 28), 1, 1),
  roof: texM(P.roof(9), 2, 2), marble: texM(P.marble(10), 1, 1), marbleTop: toon({ color: '#ece2cf' }),
  trunk: toon({ color: '#6a4a32' }), cypress: toon({ color: '#3f6b36' }), pine: toon({ color: '#5c8a3c' }), bush: toon({ color: '#6c9a42' }),
  hill: toon({ color: '#7aa64c' }), hillFar: toon({ color: '#86ad60' }), mount: toon({ color: '#8fa7b8' }), snow: toon({ color: '#f4f6fa' }),
  iron: toon({ color: '#5c5a57' }), bronze: toon({ color: '#b08a4a' }), wood: toon({ color: '#7a5434' }), door: toon({ color: '#5a3a24' }),
  window: toon({ color: '#2b2430' }), red: toon({ color: '#b8282b' }),
};
M.banner = new THREE.MeshToonMaterial({ gradientMap: grad, map: P.tex(P.banner()), alphaTest: 0.5, side: THREE.DoubleSide });
// helmet
const helmetIn = P.tex(P.helmetInside()); helmetIn.wrapS = helmetIn.wrapT = THREE.ClampToEdgeWrapping;
M.helmIn = new THREE.MeshToonMaterial({ gradientMap: grad, map: helmetIn, side: THREE.BackSide });
M.helmOut = toon({ color: '#8f8a7e' });

// ---------- ink / normal-depth contract ----------
const NOINK = 'noink'; // userData flag: never outlined (cards, fx, water handled specially)
const ndMat = new THREE.ShaderMaterial({
  vertexShader: `varying vec3 vN; varying float vD; void main(){ vN = normalize(normalMatrix*normal); vec4 mv = modelViewMatrix*vec4(position,1.); vD = -mv.z; gl_Position = projectionMatrix*mv; }`,
  fragmentShader: `varying vec3 vN; varying float vD; void main(){ vec3 n = normalize(vN); if(!gl_FrontFacing) n = -n; gl_FragColor = vec4(n*.5+.5, vD); }`,
  side: THREE.DoubleSide,
});
const cardNd = (map) => new THREE.ShaderMaterial({
  uniforms: { map: { value: map } },
  vertexShader: `varying vec2 vUv; varying float vD; void main(){ vUv=uv; vec4 mv = modelViewMatrix*vec4(position,1.); vD=-mv.z; gl_Position=projectionMatrix*mv; }`,
  fragmentShader: `uniform sampler2D map; varying vec2 vUv; varying float vD; void main(){ if(texture2D(map,vUv).a<.5) discard; gl_FragColor=vec4(0.,0.,0.,vD); }`,
  side: THREE.DoubleSide,
});
const waterNd = new THREE.ShaderMaterial({
  vertexShader: `varying float vD; void main(){ vec4 mv = modelViewMatrix*vec4(position,1.); vD=-mv.z; gl_Position=projectionMatrix*mv; }`,
  fragmentShader: `varying float vD; void main(){ gl_FragColor=vec4(.5,1.,.5,vD); }`,
});

// ---------- helpers ----------
const add = (geo, mat, x = 0, y = 0, z = 0, parent = scene, opts = {}) => {
  const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = opts.cast ?? true; m.receiveShadow = true; parent.add(m); return m;
};
const box = (w, h, d) => new THREE.BoxGeometry(w, h, d);
const uvScale = (geo, su, sv) => { const uv = geo.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * su, uv.getY(i) * sv); return geo; };
/** box with world-scaled UVs per face (texel density 1 tile per `t` metres) */
const tbox = (w, h, d, t = 2) => {
  const g = box(w, h, d), uv = g.attributes.uv;
  const dims = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
  for (let f = 0; f < 6; f++) for (let k = 0; k < 4; k++) { const i = f * 4 + k; uv.setXY(i, uv.getX(i) * dims[f][0] / t, uv.getY(i) * dims[f][1] / t); }
  return g;
};

// ---------- sky ----------
const skyU = { top: { value: new THREE.Color() }, hor: { value: new THREE.Color() }, sunDir: { value: new THREE.Vector3() }, sunCol: { value: new THREE.Color() }, sunSize: { value: 0 } };
const sky = new THREE.Mesh(new THREE.SphereGeometry(1200, 32, 16), new THREE.ShaderMaterial({
  uniforms: skyU, side: THREE.BackSide, depthWrite: false, fog: false,
  vertexShader: `varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.); }`,
  fragmentShader: `uniform vec3 top, hor, sunDir, sunCol; uniform float sunSize; varying vec3 vP;
    void main(){ float h = clamp(vP.y,0.,1.); vec3 c = mix(hor, top, pow(h, .55)); if(vP.y<0.) c = hor;
      float s = dot(normalize(vP), normalize(sunDir)); c += sunCol * (smoothstep(1.-sunSize, 1.-sunSize*.6, s) + .35*pow(max(s,0.), 24.)*step(.001,sunSize));
      gl_FragColor = vec4(c,1.); }`,
}));
sky.userData.sky = true; scene.add(sky);

// ---------- lights ----------
const hemi = new THREE.HemisphereLight('#ffffff', '#ffffff', 1); scene.add(hemi);
const sun = new THREE.DirectionalLight('#ffffff', 2); sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048); sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.03; sun.shadow.radius = 2;
scene.add(sun); scene.add(sun.target);
scene.fog = new THREE.Fog('#ffffff', 40, 600);

// ---------- world: "The Ice That Sailed to India" ----------
const DECK = 0;
const PL = PLACES;
const world = new THREE.Group(); scene.add(world);
const waterU = { t: { value: 0 }, deep: { value: new THREE.Color('#2f6f8f') }, shal: { value: new THREE.Color('#5fa8bf') }, glint: { value: new THREE.Color('#e9f6ff') } };
const waterMat = new THREE.ShaderMaterial({
  uniforms: { ...THREE.UniformsUtils.clone(THREE.UniformsLib.fog), ...waterU }, fog: true,
  vertexShader: `#include <fog_pars_vertex>
    varying vec3 vW; void main(){ vec4 w = modelMatrix*vec4(position,1.); vW = w.xyz; vec4 mvPosition = viewMatrix*w; gl_Position = projectionMatrix*mvPosition;
    #include <fog_vertex>
    }`,
  fragmentShader: `#include <fog_pars_fragment>
    uniform float t; uniform vec3 deep, shal, glint; varying vec3 vW;
    float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
    float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f); return mix(mix(hash(i),hash(i+vec2(1,0)),f.x), mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x), f.y); }
    void main(){ vec2 p = vW.xz*vec2(.35,.12) + vec2(0., -t*.25);
      float n = noise(p) * .6 + noise(p*2.3 + 7.) * .4; float edge = smoothstep(10., 17., 0.);
      vec3 c = mix(deep, shal, .35 + .4*n + .4*edge);
      float streak = smoothstep(.72, .78, noise(vW.xz*vec2(.8,.09) + vec2(0., -t*.6))) * (1.-edge*.5);
      c = mix(c, glint, streak*.75);
      gl_FragColor = vec4(c,1.);
      #include <fog_fragment>
    }`,
});
const water = new THREE.Mesh(new THREE.PlaneGeometry(1400, 1400), waterMat); water.rotation.x = -Math.PI / 2; water.position.y = 0;
water.userData.nd = waterNd; water.receiveShadow = false; scene.add(water);
const seaPlane = (cx, cz, w, d, y) => { const mm = new THREE.Mesh(new THREE.PlaneGeometry(w, d), waterMat); mm.rotation.x = -Math.PI / 2; mm.position.set(cx, y, cz); mm.userData.nd = waterNd; mm.receiveShadow = false; scene.add(mm); return mm; };
scene.remove(water);
// ---- painted materials ----
const sMat = (c, extra = {}) => new THREE.MeshToonMaterial({ gradientMap: grad, color: c, ...extra });
const tMat = (canvas, rx, ry, extra = {}) => new THREE.MeshToonMaterial({ gradientMap: grad, map: P.tex(canvas, rx, ry), ...extra });
const gT = (canvas, w, d, tile) => tMat(canvas, w / tile, d / tile);
const C2 = { snow: P2.snow(), ice: P2.ice(), pond: P2.pond(), hull: P2.hull(), sail: P2.sail(), sand: P2.sand(), cobble: P2.cobble(), saw: P2.sawdust(), quilt: P2.quilt(), tiles: P2.tiles(), stripes: P2.stripes(), flag: P2.flag() };
M.plaster3 = texM(P.plaster(31, 18), 1, 1); M.plaster4 = texM(P.plaster(41, 165), 1, 1);
const MM = {
  ice: tMat(C2.ice, 1, 1, { emissive: new THREE.Color('#2e5470') }), pond: tMat(C2.pond, 5, 5), hull: tMat(C2.hull, 0.22, 0.22, { emissive: new THREE.Color('#14203a') }),
  sail: tMat(C2.sail, 1, 1, { side: THREE.DoubleSide, emissive: new THREE.Color('#a89878') }), saw: tMat(C2.saw, 1, 1, { emissive: new THREE.Color('#6a4e22') }),
  jacket: tMat(C2.quilt, 4, 3), roof: tMat(C2.tiles, 3, 3, { side: THREE.DoubleSide }), awning: tMat(C2.stripes, 1, 1, { side: THREE.DoubleSide }),
  flag: tMat(C2.flag, 1, 1, { side: THREE.DoubleSide }), stave: tMat(P.planks(9), 3, 1), crate: tMat(P.planks(4), 1, 1), logs: tMat(P.beam(6, [40, 36, 26]), 2, 1),
  cut: sMat('#36657f'), cabin: sMat('#c9a56a'), cloth: sMat('#f4f0e6'), glass: sMat('#bfe8f6'), wall: sMat('#efe3c8', { side: THREE.DoubleSide }),
  dark: sMat('#2a2230'), pine: sMat('#4f7a4a'), oak: sMat('#6a9a45'), rope: sMat('#a8864f'), palm: sMat('#4f8f3a', { side: THREE.DoubleSide }),
  snowM: sMat('#e9ede4'), cream: sMat('#f4e9d0'), shutter: sMat('#3f6a58'), pot: sMat('#b5653f'), plankD: sMat('#5a3a22'), reed: sMat('#9a9650'),
  glow: sMat('#fff0b8', { emissive: new THREE.Color('#ffd070') }),
};
// ---- helpers ----
const patchMat = (base, w, d, scale = 0.25) => { const mm = base.clone(); mm.map = base.map.clone(); mm.map.repeat.set(w * scale, d * scale); mm.map.needsUpdate = true; return mm; };
const ground = (mat, cx, cz, w, d, y = -0.02) => { const mm = add(new THREE.PlaneGeometry(w, d), mat, cx, y, cz, world, { cast: false }); mm.rotation.x = -Math.PI / 2; return mm; };
const disc = (mat, cx, cz, r, y) => { const mm = add(new THREE.CircleGeometry(r, 48), mat, cx, y, cz, world, { cast: false }); mm.rotation.x = -Math.PI / 2; return mm; };
const cyl = (rt, rb, h, seg = 12) => new THREE.CylinderGeometry(rt, rb, h, seg);
const iceStack = (parent, x0, y0, z0, nx, nz, l0, l1) => { for (let l = l0; l < l1; l++) for (let i = 0; i < nx; i++) for (let k = 0; k < nz; k++) add(box(0.9, 0.5, 0.6), MM.ice, x0 + i * 0.92 + 0.45, y0 + l * 0.52 + 0.25, z0 + k * 0.62 + 0.3, parent); };
const ropeTo = (a, b, r = 0.035, parent = world) => { const va = new THREE.Vector3(...a), vb = new THREE.Vector3(...b), d = vb.clone().sub(va), L = d.length();
  const mm = add(cyl(r, r, L, 5), MM.rope, 0, 0, 0, parent, { cast: false }); mm.position.copy(va).addScaledVector(d, 0.5); mm.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize()); return mm; };
const barrel = (parent, x, y, z, s = 1) => { const g = new THREE.Group(); g.position.set(x, y, z); parent.add(g);
  add(cyl(0.44 * s, 0.44 * s, 0.9 * s, 14), MM.stave, 0, 0.45 * s, 0, g); add(cyl(0.52 * s, 0.52 * s, 0.5 * s, 14), MM.stave, 0, 0.45 * s, 0, g);
  for (const [yy, rr] of [[0.1, 0.46], [0.28, 0.54], [0.62, 0.54], [0.8, 0.46]]) add(cyl(rr * s, rr * s, 0.05 * s, 14), M.iron, 0, yy * s, 0, g); return g; };
const crate = (parent, x, y, z, s = 0.9, rot = 0) => { const g = new THREE.Group(); g.position.set(x, y, z); g.rotation.y = rot; parent.add(g);
  add(tbox(s, s, s, s), MM.crate, 0, s / 2, 0, g); for (const [dx, dz] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) add(box(0.08 * s, s * 1.02, 0.08 * s), M.beam, dx * s / 2, s / 2, dz * s / 2, g); return g; };
const coil = (parent, x, y, z) => { for (let k = 0; k < 3; k++) { const t = add(new THREE.TorusGeometry(0.34 - k * 0.03, 0.07, 6, 16), MM.rope, x, y + 0.08 + k * 0.12, z, parent, { cast: false }); t.rotation.x = Math.PI / 2; } };
const lamp = (parent, x, z, h = 2.4) => { add(cyl(0.05, 0.07, h, 6), M.iron, x, h / 2, z, parent); add(box(0.3, 0.36, 0.3), MM.glow, x, h + 0.12, z, parent, { cast: false }); add(new THREE.ConeGeometry(0.26, 0.2, 4), M.iron, x, h + 0.4, z, parent).rotation.y = Math.PI / 4; };
const drift = (x, z, r) => { const mm = add(new THREE.SphereGeometry(r, 14, 8), MM.snowM, x, 0, z, world, { cast: false }); mm.scale.y = 0.32; };
const tree = (x, z, h = 6, kind = 'pine', snowy = true) => { const g = new THREE.Group(); g.position.set(x, 0, z); world.add(g); add(cyl(0.18, 0.26, h * 0.35, 6), M.trunk, 0, h * 0.175, 0, g);
  if (kind === 'pine') { add(new THREE.ConeGeometry(h * 0.2, h * 0.8, 8), MM.pine, 0, h * 0.62, 0, g); if (snowy) add(new THREE.ConeGeometry(h * 0.12, h * 0.26, 8), MM.snowM, 0, h * 0.94, 0, g); }
  else { const c = add(new THREE.SphereGeometry(h * 0.32, 10, 8), MM.oak, 0, h * 0.62, 0, g); c.scale.y = 0.9; } };
const palm = (x, z, h = 8, lean = 0.08) => { const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.z = lean; world.add(g);
  add(cyl(0.16, 0.28, h, 7), M.trunk, 0, h / 2, 0, g);
  for (let i = 0; i < 9; i++) { const fg = box(0.5, 0.05, 3.2); fg.translate(0, 0, 1.6); const f = add(fg, MM.palm, 0, h, 0, g, { cast: false }); f.rotation.y = (i * Math.PI * 2) / 9; f.rotation.x = -0.45; } };
const reeds = (x, z) => { for (let k = 0; k < 6; k++) { const mm = add(new THREE.ConeGeometry(0.05, 1.1 + (k % 3) * 0.3, 4), MM.reed, x + (k % 3) * 0.12, 0.55, z + (k >> 1) * 0.1, world, { cast: false }); mm.rotation.z = (k - 2.5) * 0.08; } };
const gable = (w, d, h, mat, parent) => { const sh = new THREE.Shape(); sh.moveTo(-d / 2 - 0.3, 0); sh.lineTo(d / 2 + 0.3, 0); sh.lineTo(0, h); sh.closePath();
  const g = new THREE.ExtrudeGeometry(sh, { depth: w + 0.6, bevelEnabled: false }); g.translate(0, 0, -(w + 0.6) / 2); g.rotateY(Math.PI / 2); return add(g, mat, 0, 0, 0, parent); };
const shed = (x, z, rot, w, d, h, roofMat, wallMat = MM.crate) => { const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = rot; world.add(g);
  add(tbox(w, h, d, 1.2), wallMat, 0, h / 2, 0, g); const r = gable(w, d, 1.6, roofMat, g); r.position.y = h;
  add(box(1.4, 2.2, 0.14), MM.dark, 0, 1.1, d / 2 + 0.03, g, { cast: false }); add(box(1.8, 0.14, 0.2), M.beam, 0, 2.3, d / 2 + 0.05, g, { cast: false }); return g; };
/** a Calcutta house: plinth, shuttered windows, arched door with awning, balconies, tiled roof */
const colHouse = (x, z, rot, w, d, h, wall) => { const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = rot; world.add(g); const f = d / 2;
  add(tbox(w, h, d, 2), wall, 0, h / 2, 0, g); add(box(w + 0.3, 0.5, d + 0.3), M.stone, 0, 0.25, 0, g); add(box(w + 0.6, 0.28, d + 0.6), MM.cream, 0, h, 0, g);
  const rf = add(new THREE.ConeGeometry(Math.hypot(w, d) / 2 + 0.6, 2.0, 4), MM.roof, 0, h + 1.15, 0, g); rf.rotation.y = Math.PI / 4; rf.scale.set((w / Math.hypot(w, d)) * 1.414, 1, (d / Math.hypot(w, d)) * 1.414);
  add(box(0.7, 1.6, 0.7), M.stone, w * 0.3, h + 1.4, -d * 0.2, g);
  const win = (wx, wy) => { add(box(1.05, 1.4, 0.1), MM.cream, wx, wy, f + 0.01, g, { cast: false }); add(box(0.72, 1.08, 0.12), M.window, wx, wy, f + 0.04, g, { cast: false });
    for (const s of [-1, 1]) add(box(0.4, 1.3, 0.08), MM.shutter, wx + s * 0.72, wy, f + 0.05, g, { cast: false }); };
  for (const wx of [-w * 0.3, w * 0.3]) win(wx, 1.6);
  for (const wx of [-w * 0.3, 0, w * 0.3]) { win(wx, h * 0.72); add(box(1.9, 0.1, 0.65), M.wood, wx, h * 0.72 - 0.85, f + 0.32, g); add(box(1.9, 0.06, 0.05), M.wood, wx, h * 0.72 - 0.35, f + 0.62, g); for (const s of [-1, 0, 1]) add(box(0.05, 0.5, 0.05), M.wood, wx + s * 0.9, h * 0.72 - 0.6, f + 0.62, g); }
  add(box(1.7, 2.7, 0.1), MM.cream, 0, 1.35, f + 0.01, g, { cast: false }); add(box(1.2, 2.2, 0.12), M.door, 0, 1.1, f + 0.04, g, { cast: false });
  const aw = add(box(2.4, 0.08, 1.2), MM.awning, 0, 2.85, f + 0.6, g); aw.rotation.x = 0.35;
  for (const s of [-1, 1]) { add(cyl(0.2, 0.15, 0.4, 8), MM.pot, s * 1.5, 0.2, f + 0.5, g); add(new THREE.SphereGeometry(0.28, 8, 6), MM.oak, s * 1.5, 0.62, f + 0.5, g); }
  return g; };
/** the brig Tuscany: two masts, three stitched square sails each, shrouds, flag, deck cargo; bow +z */
const hullGeo = (len, wid, hgt, y0) => { const sh = new THREE.Shape(); sh.moveTo(-wid / 2, len / 2); sh.lineTo(wid / 2, len / 2); sh.lineTo(wid / 2, -len * 0.18); sh.lineTo(0, -len / 2); sh.lineTo(-wid / 2, -len * 0.18); sh.closePath();
  const g = new THREE.ExtrudeGeometry(sh, { depth: hgt, bevelEnabled: false }); g.rotateX(-Math.PI / 2); g.translate(0, y0, 0); return g; };
const makeShip = () => {
  const g = new THREE.Group(); scene.add(g);
  add(hullGeo(26, 7, 3.3, -1.5), MM.hull, 0, 0, 0, g);
  add(box(7.2, 0.18, 26.4), M.beam, 0, 1.78, -1.4, g); // gunwale band
  add(tbox(6.4, 0.08, 22, 2), M.plank, 0, 1.84, -1.5, g);
  for (const s of [-1, 1]) { add(box(0.12, 0.14, 22), M.wood, s * 3.3, 2.7, -1.5, g); for (let z = -11; z <= 8; z += 2.2) add(box(0.1, 0.9, 0.1), M.wood, s * 3.3, 2.25, z, g); }
  for (const z of [-4, 5]) {
    add(box(0.36, 15.2, 0.36), M.wood, 0, 9.4, z, g);
    for (const [y, w, h] of [[4.0, 8.0, 4.2], [9.0, 6.6, 3.8], [13.2, 4.6, 3.0]]) { add(box(w, 0.15, 0.2), M.wood, 0, y + h + 0.07, z, g); add(box(w - 0.4, h, 0.08), MM.sail, 0, y + h / 2, z, g); }
    for (const s of [-1, 1]) for (const dz of [-1.2, 1.2]) ropeTo([0, 11.5, z], [s * 3.2, 2.0, z + dz], 0.035, g);
  }
  ropeTo([0, 16.5, -4], [0, 16.5, 5], 0.03, g); ropeTo([0, 16.5, 5], [0, 2.2, 14.5], 0.03, g);
  add(box(0.3, 0.3, 6), M.wood, 0, 2.05, 12, g);
  const fl = add(new THREE.PlaneGeometry(2.4, 1.4), MM.flag, 0, 16.3, 6.4, g, { cast: false }); fl.rotation.y = Math.PI / 2;
  add(box(5.6, 2.4, 4), MM.cabin, 0, 3.05, -10.5, g); add(box(0.9, 1.5, 0.1), MM.dark, 0, 2.7, -8.45, g, { cast: false }); for (const s of [-1, 1]) add(box(0.7, 0.6, 0.1), MM.dark, s * 1.7, 3.5, -8.45, g, { cast: false });
  barrel(g, 1.6, 1.86, -6.5); barrel(g, 2.2, 1.86, -5.6, 0.9); crate(g, -1.9, 1.86, 1.5); crate(g, -1.9, 2.76, 1.5, 0.7, 0.3); coil(g, 1.4, 1.86, 3.2);
  return g;
};
const mooredShip = makeShip(); mooredShip.position.set(PL.BOSTON[0] - 8, 0, PL.BOSTON[2] - 46); mooredShip.rotation.y = Math.PI / 2;
const seaShip = makeShip(); seaShip.visible = false;

const heroSled = new THREE.Group(); world.add(heroSled);
const driftIce = new THREE.Group(); world.add(driftIce);
// ---- BOSTON: snow, frozen pond with a cut channel, ice sleds, shed, wharf with cargo, harbour ----
{
  const B = PL.BOSTON, W0 = PL.WHARF;
  ground(gT(C2.snow, 3000, 1540, 10), B[0], B[2] + 730, 3000, 1540);
  disc(MM.pond, B[0], B[2], 26, 0.02);
  const ch = add(new THREE.PlaneGeometry(8, 10), MM.cut, B[0] + 1, 0.03, B[2] + 13, world, { cast: false }); ch.rotation.x = -Math.PI / 2;
  for (let i = 0; i < 5; i++) add(box(1.1, 0.5, 0.8), MM.ice, B[0] - 1.8 + i * 1.5, 0.28, B[2] + 10.4 + (i % 2) * 2.4, world);
  for (const [x, z] of [[-8, 0.5], [9.5, 2.2]]) { add(box(2.2, 0.12, 1.6), M.wood, W0[0] + x, 0.06, W0[2] + z, world); iceStack(world, W0[0] + x - 0.9, 0.12, W0[2] + z - 0.62, 2, 2, 0, 3); }
  add(box(2.9, 0.14, 2.0), M.wood, W0[0] + 0.2, 0.07, W0[2], heroSled); iceStack(heroSled, W0[0] + 0.2 - 1.38, 0.14, W0[2] - 0.93, 3, 3, 0, 3);
  for (const s of [-1, 1]) add(box(0.1, 0.1, 2.4), M.beam, W0[0] + 0.2 + s * 1.2, 0.03, W0[2], heroSled);
  add(tbox(28, 0.15, 10, 2), M.plank, W0[0], -0.075, W0[2] - 0.5, world);
  for (let x = -13; x <= 13; x += 4) { add(cyl(0.25, 0.25, 2.4, 8), M.beam, W0[0] + x, -0.5, W0[2] - 5.7, world); add(cyl(0.3, 0.3, 0.7, 8), M.beam, W0[0] + x, 0.35, W0[2] - 5.1, world); }
  ['#efe6c8', '#d8b86a', '#2b2b30', '#7a4f33'].forEach((col, k) => { const mm = add(new THREE.SphereGeometry(0.5, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), sMat(col), W0[0] - 3 + 2 * k, 0, W0[2], world); mm.scale.y = 0.7; });
  add(new THREE.SphereGeometry(1.15, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2), MM.saw, W0[0] + 5, 0, W0[2], world).scale.y = 0.8;
  barrel(world, W0[0] - 11, 0, W0[2] + 3); barrel(world, W0[0] - 10.2, 0, W0[2] + 3.6, 0.9); crate(world, W0[0] + 12, 0, W0[2] + 3, 1, 0.3); crate(world, W0[0] + 12.2, 1, W0[2] + 3.1, 0.7, 0.9); coil(world, W0[0] + 8, 0, W0[2] + 3.5);
  lamp(world, W0[0] - 12.5, W0[2] - 3.5); lamp(world, W0[0] + 12.5, W0[2] - 3.5);
  shed(B[0] - 16, B[2] - 22, 0.2, 6, 4.5, 3.2, MM.snowM); shed(B[0] + 20, B[2] - 20, -0.3, 5, 4, 3, MM.snowM);
  for (let k = 0; k < 14; k++) { const a = (k / 14) * Math.PI * 2 + 0.2, z = B[2] + Math.sin(a) * 36 + 10; if (z < B[2] + 12) continue; tree(B[0] + Math.cos(a) * 36, z, 6 + (k % 4), 'pine'); }
  for (let k = 0; k < 26; k++) { const a = k * 0.63; drift(B[0] + Math.cos(a) * (28 + (k % 5) * 5), B[2] + 10 + Math.sin(a) * (20 + (k % 4) * 6), 1.4 + (k % 3) * 0.7); }
  for (let k = 0; k < 18; k++) { const a = (k / 18) * Math.PI * 2; reeds(B[0] + Math.cos(a) * 26.3, B[2] + Math.sin(a) * 26.3); }
  seaPlane(B[0], B[2] - 790, 3000, 1500, -0.9);
}

// ---- CALCUTTA: sand, cobbled street, colonial houses, verandah, palms, ice house, tables ----
{
  const C = PL.CAL, walls = [M.plaster, M.plaster2, M.plaster3, M.plaster4];
  ground(gT(C2.sand, 3000, 3000, 6), C[0], C[2], 3000, 3000);
  const st = add(new THREE.PlaneGeometry(10, 100), tMat(C2.cobble, 2, 20), C[0], 0.012, C[2], world, { cast: false }); st.rotation.x = -Math.PI / 2;
  for (let k = 0, z = -34; z <= 34; k++, z += 9) { colHouse(C[0] - 11, C[2] + z, Math.PI / 2, 8, 8, k % 2 ? 7 : 8.4, walls[k % 4]); colHouse(C[0] + 11, C[2] + z + 4, -Math.PI / 2, 8, 8, k % 2 ? 8.4 : 7, walls[(k + 2) % 4]); }
  add(box(3.6, 0.12, 3.6), M.plank, C[0] - 5.2, 1.94, C[2] + 2.0, world); // verandah where the bishop stands
  for (const z of [0.3, 3.7]) add(box(0.14, 3.4, 0.14), M.wood, C[0] - 3.5, 1.7, C[2] + z, world);
  add(box(0.14, 0.1, 3.6), M.wood, C[0] - 3.5, 2.95, C[2] + 2.0, world);
  shed(C[0] + 21, C[2] - 10, -Math.PI / 2, 8, 8, 6, MM.roof, M.stone);
  add(box(3.4, 0.08, 1.4), MM.cloth, C[0], 0.78, C[2] + 6, world);
  for (const [x, z] of [[-1.5, 5.4], [1.5, 5.4], [-1.5, 6.6], [1.5, 6.6]]) add(box(0.1, 0.74, 0.1), M.wood, C[0] + x, 0.37, C[2] + z, world);
  for (let k = 0; k < 8; k++) add(cyl(0.07, 0.06, 0.2, 8), MM.glass, C[0] - 1.3 + k * 0.4, 0.92, C[2] + 5.6 + (k % 2) * 0.7, world);
  add(box(0.7, 0.6, 0.5), MM.ice, C[0], 1.12, C[2] + 6, world);
  for (let z = -30; z <= 30; z += 15) { palm(C[0] - 6.4, C[2] + z, 8 + (z % 4), 0.1); palm(C[0] + 6.4, C[2] + z + 7, 9, -0.1); }
  for (const z of [-20, 8, 26]) { lamp(world, C[0] - 5.2, C[2] + z); lamp(world, C[0] + 5.2, C[2] + z + 3); }
  barrel(world, C[0] - 6.2, 0, C[2] - 8); barrel(world, C[0] - 6.8, 0, C[2] - 7.2, 0.9); crate(world, C[0] + 6.4, 0, C[2] - 3, 1, 0.2); crate(world, C[0] + 6.6, 1, C[2] - 2.9, 0.7, 0.8); crate(world, C[0] + 6.2, 0, C[2] + 14, 0.9, 0.5);
  for (let k = 0; k < 12; k++) palm(C[0] + (k % 2 ? 1 : -1) * (32 + (k >> 1) * 5), C[2] + ((k * 13) % 50) - 25, 9, 0.06);
}

// ---- HOLD: open-fronted room, 0.46 m of sawdust between two plank layers on each side ----
const holdTop = new THREE.Group(); world.add(holdTop);
{
  const H = PL.HOLD;
  ground(M.plank.clone(), H[0], H[2], 28, 28, 0);
  add(box(6.4, 4, 0.2), MM.plankD, H[0], 2, H[2] + 7.6, world);
  for (let x = -3; x <= 3; x += 1.5) add(box(0.22, 3.8, 0.3), M.beam, H[0] + x, 1.9, H[2] + 7.4, world);
  for (const s of [-1, 1]) { const x = (a, c) => H[0] + s * (a + c) / 2; const L = 9.8, zc = H[2] + 2.7;
    add(box(0.06, 3.5, L), MM.plankD, x(2.44, 2.5), 1.75, zc, world); add(tbox(0.46, 3.5, L, 1.0), MM.saw, x(2.5, 2.96), 1.75, zc, world); add(box(0.06, 3.5, L), MM.plankD, x(2.96, 3.02), 1.75, zc, world);
    for (let z = -1.5; z <= 7; z += 2.1) add(box(0.14, 3.6, 0.22), M.beam, x(2.3, 2.3), 1.8, H[2] + z, world); }
  iceStack(world, H[0] + 0.45, 0, H[2] - 0.6, 2, 9, 0, 3);
  iceStack(holdTop, H[0] + 0.45, 0, H[2] - 0.6, 2, 9, 3, 6);
  add(cyl(0.13, 0.15, 1.3, 10), M.stone, H[0] - 1.9, 0.65, H[2], world); add(box(1.0, 0.08, 0.1), M.wood, H[0] - 1.9, 1.29, H[2], world);
  const pd = add(new THREE.PlaneGeometry(1.2, 1.6), MM.cut, H[0] - 0.9, 0.012, H[2] + 0.1, world, { cast: false }); pd.rotation.x = -Math.PI / 2;
  barrel(world, H[0] - 2.2, 0, H[2] + 6.6); barrel(world, H[0] - 1.4, 0, H[2] + 6.8, 0.9); crate(world, H[0] - 2.3, 0, H[2] + 4.6, 1, 0.1); coil(world, H[0] - 2.3, 0, H[2] + 2.8); lamp(world, H[0] + 2.2, H[2] + 6.8, 3.0);
}

// ---- SEA: open water only (the second Tuscany sails here) ----
seaPlane(PL.SEA[0], PL.SEA[2], 3000, 3000, -0.5);

// ---- JACKET analogy set ----
{
  const J = PL.JACKET;
  ground(patchMat(M.grass, 3000, 3000), J[0], J[2], 3000, 3000);
  add(box(1.8, 1.6, 1.8), MM.ice, J[0] + 4.5, 0.8, J[2] + 3, world);
  for (let k = 0; k < 14; k++) { const a = (k / 14) * Math.PI * 2; for (const y of [0.3, 0.8, 1.3]) { const s = add(new THREE.SphereGeometry(0.42, 12, 8), MM.jacket, J[0] + 4.5 + Math.cos(a) * 1.15, y, J[2] + 3 + Math.sin(a) * 1.15, world); s.scale.y = 0.72; } }
  for (let k = 0; k < 6; k++) { const s = add(new THREE.SphereGeometry(0.5, 12, 8), MM.jacket, J[0] + 4.5 + (k % 3 - 1) * 0.6, 1.62, J[2] + 2.5 + (k >> 1) * 0.5, world); s.scale.y = 0.4; }
  for (let k = 0; k < 10; k++) tree(J[0] + (k % 2 ? 1 : -1) * (14 + (k >> 1) * 3), J[2] + 8 + k * 2, 7, 'oak');
}

// ---- WALDEN beside the GANGES: snow, Thoreau's cabin and ice crew on one side, palms on the other ----
{
  const Wd = PL.WALDEN;
  ground(gT(C2.snow, 1522, 3000, 10), Wd[0] - 739, Wd[2], 1522, 3000);
  disc(MM.pond, Wd[0], Wd[2], 22, 0.02);
  for (const s of [-1, 1]) ground(patchMat(M.grass, 1500, 1500), Wd[0] + 772, Wd[2] + s * 764, 1500, 1500);
  seaPlane(Wd[0] + 772, Wd[2], 1500, 28, -0.5);
  shed(Wd[0] - 9, Wd[2] - 11, 0.4, 4, 3.2, 2.8, MM.snowM, MM.logs);
  add(box(0.8, 3.6, 0.8), M.stone, Wd[0] - 11, 1.8, Wd[2] - 12.4, world);
  for (const [x, z] of [[-6, 9], [-1, 11], [4, 9.5]]) iceStack(world, Wd[0] + x, 0.02, Wd[2] + z, 2, 2, 0, 2);
  for (let k = 0; k < 10; k++) for (const s of [-1, 1]) palm(Wd[0] + 30 + k * 11, Wd[2] + s * (18 + (k % 3) * 3), 8 + (k % 3), 0.06 * s);
  for (let k = 0; k < 16; k++) { const b = add(box(0.9 + (k % 3) * 0.25, 0.45, 0.7 + (k % 2) * 0.3), MM.ice, 0, -0.2, 0, driftIce); b.userData.x0 = (k * 7.3) % 70; b.userData.z = ((k * 37) % 18) - 9; b.rotation.y = k * 0.7; }
  for (const [cx, cz] of [[36, 2.5], [58, -3.5], [80, 1.5]]) { const cn = add(hullGeo(6.5, 1.2, 0.55, -0.55), MM.cabin, Wd[0] + cx, 0, Wd[2] + cz, world); cn.rotation.y = Math.PI / 2 + (cz > 0 ? 0.08 : -0.06); add(box(0.08, 0.08, 2.2), M.wood, Wd[0] + cx, 0.2, Wd[2] + cz + 0.9, world).rotation.y = 0.5; }
  for (let k = 0; k < 12; k++) tree(Wd[0] - 28 - k * 6, Wd[2] + ((k * 23) % 50) - 25, 8, 'pine');
  for (let k = 0; k < 16; k++) { const a = (k / 16) * Math.PI * 2; reeds(Wd[0] + Math.cos(a) * 22.3, Wd[2] + Math.sin(a) * 22.3); drift(Wd[0] - 30 - (k % 5) * 6, Wd[2] + ((k * 7) % 30) - 15, 1.6); }
}

// ---- CHENNAI: the round Madras ice house, colonnade, steps ----
{
  const K = PL.CHENNAI;
  ground(gT(C2.sand, 3000, 3000, 6), K[0], K[2], 3000, 3000);
  for (let k = 0; k < 3; k++) add(cyl(9.4 - k * 0.6, 9.5 - k * 0.6, 0.2, 40), M.stone, K[0], 0.1 + k * 0.2, K[2], world);
  add(cyl(7.4, 7.6, 0.5, 40), M.stone, K[0], 0.7, K[2], world);
  add(new THREE.CylinderGeometry(7, 7, 5.5, 40, 1, true), MM.wall, K[0], 3.45, K[2], world);
  add(cyl(8.1, 8.1, 0.35, 40), MM.cream, K[0], 6.4, K[2], world);
  add(new THREE.ConeGeometry(8.5, 3.6, 40), MM.roof, K[0], 8.4, K[2], world);
  add(new THREE.SphereGeometry(0.5, 10, 8), M.bronze, K[0], 10.4, K[2], world);
  for (let k = 0; k < 14; k++) { const a = (k / 14) * Math.PI * 2; add(cyl(0.3, 0.34, 5.4, 10), MM.cream, K[0] + Math.sin(a) * 7.7, 3.4, K[2] + Math.cos(a) * 7.7, world); add(box(0.8, 0.2, 0.8), MM.cream, K[0] + Math.sin(a) * 7.7, 6.2, K[2] + Math.cos(a) * 7.7, world); }
  for (let k = 0; k < 10; k++) { const a = (k / 10) * Math.PI * 2 + 0.15; const w = add(box(1.1, 2.6, 0.15), MM.dark, K[0] + Math.sin(a) * 7.02, 2.4, K[2] + Math.cos(a) * 7.02, world); w.rotation.y = a; }
  for (let k = 0; k < 10; k++) palm(K[0] + Math.cos(k * 0.7) * 32, K[2] + Math.sin(k * 0.7) * 32, 9, 0.07);
  lamp(world, K[0] + 6, K[2] - 11); lamp(world, K[0] - 6, K[2] - 11);
}

// clouds: painted billboards far away (no fog, no ink)
const clouds = [];
{ const r = P.rng(90);
  for (let i = 0; i < 14; i++) {
    const c = document.createElement('canvas'); c.width = 600; c.height = 400; const pen = new T.Pen(c.getContext('2d')); pen.ol = 0;
    pen.g.translate(300, 200); pen.g.scale(1.4, 1.2); pen.g.translate(-300, -200); T.fxCloud(pen, i + 1);
    const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 0.667), new THREE.MeshBasicMaterial({ map: P.tex(c), transparent: true, fog: false, depthWrite: false }));
    const a = r() * Math.PI * 2, d = 650 + r() * 250; m.position.set(Math.cos(a) * d, 120 + r() * 160, Math.sin(a) * d); m.scale.setScalar(160 + r() * 140);
    m.userData.ndSkip = true; m.renderOrder = -1; m.userData.p0 = m.position.clone(); scene.add(m); clouds.push(m);
  } }

// ---------- cards ----------
const CW = 1200, CH = 2000, CM = 2.25; // canvas px, card height in metres (design 600x1000 -> 2.25 m)
const cardGeo = new THREE.PlaneGeometry(CM * 0.6, CM); cardGeo.translate(0, CM / 2 - CM * 0.025, 0);
const blobTex = P.tex(P.radial('20,14,30', 0.6));
class Card {
  constructor(scale = 1) {
    [this.c, this.g] = (() => { const c = document.createElement('canvas'); c.width = CW; c.height = CH; return [c, c.getContext('2d')]; })();
    this.t = new THREE.CanvasTexture(this.c); this.t.colorSpace = THREE.SRGBColorSpace; this.t.anisotropy = 4;
    this.mat = new THREE.MeshBasicMaterial({ map: this.t, transparent: true, alphaTest: 0.02, side: THREE.DoubleSide, fog: true });
    this.mesh = new THREE.Mesh(cardGeo, this.mat); this.mesh.userData.nd = cardNd(this.t); this.mesh.castShadow = true;
    this.mesh.customDepthMaterial = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: this.t, alphaTest: 0.5 });
    this.blob = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: blobTex, transparent: true, depthWrite: false, fog: true }));
    this.blob.rotation.x = -Math.PI / 2; this.blob.userData.ndSkip = true; this.blob.renderOrder = 1;
    scene.add(this.mesh); scene.add(this.blob); this.key = ''; this.mesh.visible = this.blob.visible = false;
  }
  draw(key, fn) {
    if (key === this.key) return; this.key = key;
    const g = this.g; g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, CW, CH); g.setTransform(CW / 600, 0, 0, CH / 1000, 0, 0);
    const p = new T.Pen(g); fn(p); this.t.needsUpdate = true;
  }
}
const cards = []; const getCard = (i) => cards[i] || (cards[i] = new Card());

// ---------- render targets & post ----------
const rtColor = new THREE.WebGLRenderTarget(W, H, { samples: 4, type: THREE.HalfFloatType });
const rtNd = new THREE.WebGLRenderTarget(W, H, { type: THREE.HalfFloatType, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter });
const rtInk = new THREE.WebGLRenderTarget(W, H, { type: THREE.HalfFloatType });
const fsCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1), fsGeo = new THREE.PlaneGeometry(2, 2);
const fs = (mat) => { const s = new THREE.Scene(); s.add(new THREE.Mesh(fsGeo, mat)); return s; };
const inkU = { col: { value: rtColor.texture }, nd: { value: rtNd.texture }, res: { value: new THREE.Vector2(W, H) }, px: { value: 1.6 }, fogCol: { value: new THREE.Color() },
  sat: { value: 1.08 }, lift: { value: new THREE.Color(0, 0, 0) }, gain: { value: new THREE.Color(1, 1, 1) }, vig: { value: 0.22 }, flash: { value: 0 } };
const inkScene = fs(new THREE.ShaderMaterial({ uniforms: inkU, vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=vec4(position.xy,0.,1.); }`,
  fragmentShader: `uniform sampler2D col, nd; uniform vec2 res; uniform float px, sat, vig, flash; uniform vec3 fogCol, lift, gain; varying vec2 vUv;
  float edgeAt(vec2 uv, float r){
    vec4 c = texture2D(nd, uv); if (dot(c.rgb,c.rgb) < .01) return 0.; float d = c.a; vec3 n = c.rgb*2.-1.;
    float e = 0.; float rr = r * clamp(7./d, .62, 1.25);
    for (int i=0;i<16;i++){ float a = float(i)*.785398 + (i>7 ? .39 : 0.); float k = i>7 ? .5 : 1.;
      vec2 o = vec2(cos(a), sin(a))*rr*k/res; vec4 s = texture2D(nd, uv+o);
      float ds = s.a; bool card = dot(s.rgb,s.rgb) < .01;
      if (card && ds > 0.) continue;            // character cards: never outlined by the world ink
      if (card) ds = 1e4;                        // sky
      vec3 ns = s.rgb*2.-1.;
      e = max(e, smoothstep(.006, .02, (ds - d)/d));                           // depth jump, near side only
      if (!card && abs(ds-d)/d < .06) e = max(e, smoothstep(.88, .72, dot(n, ns)) * .9); // crease
    }
    return e * (1. - smoothstep(140., 520., d)*.8);
  }
  void main(){
    vec3 c = texture2D(col, vUv).rgb;
    float e = edgeAt(vUv, px);
    c = mix(c, vec3(.13,.09,.14), e);
    if (flash < -0.5) c = vec3(e);
    float l = dot(c, vec3(.299,.587,.114)); c = mix(vec3(l), c, sat);
    c = c*(gain - lift) + lift;
    vec2 q = vUv-.5; c *= 1. - vig*dot(q*vec2(1.,.75), q*vec2(1.,.75))*2.2;
    c = mix(c, vec3(1., .953, .863), flash);
    gl_FragColor = vec4(c,1.); }` }));
const dofU = { src: { value: rtInk.texture }, nd: { value: rtNd.texture }, res: { value: new THREE.Vector2(W, H) }, focus: { value: 5 }, cinf: { value: 0 }, near: { value: 1 } };
const dofScene = fs(new THREE.ShaderMaterial({ uniforms: dofU, vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=vec4(position.xy,0.,1.); }`,
  fragmentShader: `uniform sampler2D src, nd; uniform vec2 res; uniform float focus, cinf, near; varying vec2 vUv;
  float coc(vec2 uv){ float d = texture2D(nd, uv).a; if (d <= 0.) d = 2000.; float k = 1. - focus/d; return k > 0. ? cinf*k : min(-k*cinf*near, cinf*1.4); }
  void main(){
    float c0 = coc(vUv);
    if (cinf < .5 || c0 < .6) { gl_FragColor = linearToOutputTexel(vec4(texture2D(src, vUv).rgb, 1.)); return; }
    vec3 acc = vec3(0.); float wsum = 0.;
    for (int i=0;i<48;i++){ float fi = float(i); float r = sqrt((fi+.5)/48.); float a = fi*2.39996;
      vec2 o = vec2(cos(a), sin(a))*r*c0/res; float cs = coc(vUv+o);
      float w = smoothstep(r*c0-1.5, r*c0+.5, cs + .5);
      acc += texture2D(src, vUv+o).rgb*w; wsum += w; }
    gl_FragColor = linearToOutputTexel(vec4(acc/max(wsum,1e-3), 1.)); }` }));
// final copy with sRGB handled by the renderer output (we render to screen with linear->sRGB in the shader chunk)
dofScene.children[0].material.toneMapped = false;

// ---------- per-frame state ----------
const tmpV = new THREE.Vector3();
function applyLight(L, f) {
  hemi.color.set(L.sky); hemi.groundColor.set(L.ground); hemi.intensity = L.hemi;
  sun.color.set(L.sun); sun.intensity = L.sunI;
  scene.fog.color.set(L.fog); scene.fog.near = L.fogNear; scene.fog.far = L.fogFar;
  skyU.top.value.set(L.skyTop); skyU.hor.value.set(L.skyHor); skyU.sunCol.value.set(L.sunDisc || '#000'); skyU.sunSize.value = L.sunSize || 0;
  inkU.sat.value = L.sat; inkU.gain.value.set(L.gain || '#fff3dc'); inkU.lift.value.set(L.lift || '#14101c');
  waterU.deep.value.set(L.waterDeep); waterU.shal.value.set(L.waterShal); waterU.glint.value.set(L.glint);
}
function placeSun(L, focus) {
  // sun direction from azimuth/elevation in world space
  const az = rx(L.az), el = rx(L.el); tmpV.set(Math.cos(el) * Math.cos(az), Math.sin(el), Math.cos(el) * Math.sin(az));
  skyU.sunDir.value.copy(tmpV);
  sun.position.copy(focus).addScaledVector(tmpV, 80); sun.target.position.copy(focus);
  const ext = L.shadowExt || 30, sc = sun.shadow.camera; sc.left = -ext; sc.right = ext; sc.top = ext; sc.bottom = -ext; sc.near = 1; sc.far = 200; sc.updateProjectionMatrix();
}

function worldState(S, f) {
  seaShip.visible = !!S.seaShip;
  if (S.seaShip) { seaShip.position.set(S.seaShip[0], S.seaShip[1], S.seaShip[2]); seaShip.rotation.z = 0.025 * Math.sin(f / 30 * 1.3); }
  holdTop.visible = !!S.holdTop;
  heroSled.visible = S.id === 1;
  for (const b of driftIce.children) { b.position.set(PL.WALDEN[0] + 23 + ((b.userData.x0 + f * 0.06) % 70), -0.2 + 0.03 * Math.sin(f * 0.07 + b.userData.x0), PL.WALDEN[2] + b.userData.z * 0.6); }
  waterU.t.value = f / 30;
}

function drawActors(list, cam) {
  cards.forEach((c) => { c.mesh.visible = c.blob.visible = false; });
  list.forEach((a, i) => {
    const c = getCard(i);
    c.draw(a.key, a.draw);
    c.mesh.visible = true; c.mesh.position.set(a.x, a.y, a.z);
    const s = a.s || 1; c.mesh.scale.set(s * (a.flip ? -1 : 1), s, s);
    c.mesh.rotation.set(0, Math.atan2(cam.position.x - a.x, cam.position.z - a.z) + (a.yaw || 0), a.roll || 0);
    c.mat.color.set(a.tint || '#ffffff'); c.mat.opacity = a.alpha ?? 1;
    c.mesh.castShadow = a.shadow !== false;
    c.mesh.renderOrder = a.order || 2;
    if (a.blob !== false && (a.ground ?? a.y) < 4) { c.blob.visible = true; c.blob.position.set(a.x, (a.ground ?? a.y) + 0.02, a.z); c.blob.scale.set(0.95 * s, 0.6 * s, 1); }
  });
}

const swapForNd = (on) => {
  scene.traverse((o) => {
    if (!o.isMesh) return;
    if (on) {
      o.userData.mat0 = o.material;
      if (o.userData.ndSkip) { o.userData.vis0 = o.visible; o.visible = false; return; }
      if (o === sky || o.userData.sky) { o.userData.vis0 = o.visible; o.visible = false; return; }
      o.material = o.userData.nd || ndMat;
    } else {
      o.material = o.userData.mat0; if (o.userData.vis0 !== undefined) { o.visible = o.userData.vis0; delete o.userData.vis0; }
    }
  });
};

window.renderFrame = (f) => {
  const S = shotAt(f), L = lightFor(S, f), C = camAt(f);
  applyLight(L, f);
  camera.position.set(...C.pos); camera.up.set(0, 1, 0); camera.lookAt(...C.look); camera.rotateZ(rx(C.roll || 0));
  camera.fov = C.fov; camera.updateProjectionMatrix(); camera.updateMatrixWorld();
  const W_ = worldAt(f); worldState(W_, f);
  placeSun(L, new THREE.Vector3(...(C.shadowAt || C.look)));
  drawActors([...actorsAt(f, T), ...fxAt(f, T)], camera);
  sky.position.copy(camera.position);
  for (const c of clouds) { c.position.set(camera.position.x + c.userData.p0.x, c.userData.p0.y, camera.position.z + c.userData.p0.z); c.quaternion.copy(camera.quaternion); }
  // pass A: colour
  renderer.setRenderTarget(rtColor); renderer.setClearColor(0x000000, 1); renderer.clear(); renderer.render(scene, camera);
  // pass B: normal + depth
  const fog = scene.fog; scene.fog = null; const sm = renderer.shadowMap.enabled; renderer.shadowMap.enabled = false; renderer.shadowMap.autoUpdate = false;
  swapForNd(true); renderer.setRenderTarget(rtNd); renderer.setClearColor(0x000000, 0); renderer.clear(); renderer.render(scene, camera); swapForNd(false);
  scene.fog = fog; renderer.shadowMap.enabled = sm; renderer.shadowMap.autoUpdate = true;
  if (window.DEBUG_ND) { const dm = new THREE.MeshBasicMaterial({ map: rtNd.texture }); const ds = fs(dm); renderer.setRenderTarget(null); renderer.render(ds, fsCam); return true; }
  // ink + grade
  const D = dofAt(f);
  inkU.px.value = 2.5; inkU.flash.value = window.DEBUG_E ? -1 : (C.flash || 0); inkU.vig.value = L.vig ?? 0.22;
  renderer.setRenderTarget(rtInk); renderer.render(inkScene, fsCam);
  // lens
  dofU.focus.value = D.focus; dofU.cinf.value = D.cinf; dofU.near.value = D.near ?? 1;
  renderer.setRenderTarget(null); renderer.render(dofScene, fsCam);
  return true;
};
window.TOTAL = TOTAL;
window.ready = true;