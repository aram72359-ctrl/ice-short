import * as THREE from './lib/three.module.js';
import * as T from './toon.js';
import * as P from './paint.js';
import { SHOTS, TOTAL, shotAt, camAt, dofAt, LIGHTS, lightFor, actorsAt, worldAt, fxAt, PLACES } from './story.js';

const W = 1080, H = 1920;
const canvas = document.getElementById('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, preserveDrawingBuffer: true });
renderer.setPixelRatio(1); renderer.setSize(W, H, false);
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.NoToneMapping;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(40, W / H, 0.08, 1500);
const rx = (a) => a * Math.PI / 180;

// ---------- materials ----------
const grad = (() => { const d = new Uint8Array([90, 90, 90, 255, 255, 255, 255, 255]); const t = new THREE.DataTexture(d, 2, 1); t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true; return t; })();
const toon = (opts) => new THREE.MeshToonMaterial({ gradientMap: grad, ...opts });
const texM = (c, rx_ = 1, ry_ = 1, color = '#ffffff') => toon({ map: P.tex(c, rx_, ry_), color });
const M = {
  plank: texM(P.planks(1), 1, 6), beam: texM(P.beam(2), 1, 2), beamDark: texM(P.beam(3, [28, 36, 30]), 1, 2),
  rot: texM(P.rotten(4), 1, 1), rotB: texM(P.rotten(14), 1, 1),
  stone: texM(P.stone(4), 1, 1), stoneMoss: texM(P.mossy(P.stone(4), 5, 1.2), 1, 1),
  grass: texM(P.grass(6), 40, 40), dirt: texM(P.dirt(7), 6, 30), plaster: texM(P.plaster(8), 1, 1), plaster2: texM(P.plaster(18, 28), 1, 1),
  roof: texM(P.roof(9), 2, 2), marble: texM(P.marble(10), 1, 1), marbleTop: toon({ color: '#ece2cf' }),
  trunk: toon({ color: '#6a4a32' }), cypress: toon({ color: '#3f6b36' }), pine: toon({ color: '#5c8a3c' }), bush: toon({ color: '#6c9a42' }),
  hill: toon({ color: '#7aa64c' }), hillFar: toon({ color: '#86ad60' }), mount: toon({ color: '#8fa7b8' }), snow: toon({ color: '#f4f6fa' }),
  iron: toon({ color: '#5c5a57' }), bronze: toon({ color: '#b08a4a' }), wood: toon({ color: '#7a5434' }), door: toon({ color: '#5a3a24' }),
  window: toon({ color: '#2b2430' }), red: toon({ color: '#b8282b' }),
};
M.banner = new THREE.MeshToonMaterial({ gradientMap: grad, map: P.tex(P.banner()), alphaTest: 0.5, side: THREE.DoubleSide });
// helmet
const helmetIn = P.tex(P.helmetInside()); helmetIn.wrapS = helmetIn.wrapT = THREE.ClampToEdgeWrapping;
M.helmIn = new THREE.MeshToonMaterial({ gradientMap: grad, map: helmetIn, side: THREE.BackSide });
M.helmOut = toon({ color: '#8f8a7e' });

// ---------- ink / normal-depth contract ----------
const NOINK = 'noink'; // userData flag: never outlined (cards, fx, water handled specially)
const ndMat = new THREE.ShaderMaterial({
  vertexShader: `varying vec3 vN; varying float vD; void main(){ vN = normalize(normalMatrix*normal); vec4 mv = modelViewMatrix*vec4(position,1.); vD = -mv.z; gl_Position = projectionMatrix*mv; }`,
  fragmentShader: `varying vec3 vN; varying float vD; void main(){ vec3 n = normalize(vN); if(!gl_FrontFacing) n = -n; gl_FragColor = vec4(n*.5+.5, vD); }`,
  side: THREE.DoubleSide,
});
const cardNd = (map) => new THREE.ShaderMaterial({
  uniforms: { map: { value: map } },
  vertexShader: `varying vec2 vUv; varying float vD; void main(){ vUv=uv; vec4 mv = modelViewMatrix*vec4(position,1.); vD=-mv.z; gl_Position=projectionMatrix*mv; }`,
  fragmentShader: `uniform sampler2D map; varying vec2 vUv; varying float vD; void main(){ if(texture2D(map,vUv).a<.5) discard; gl_FragColor=vec4(0.,0.,0.,vD); }`,
  side: THREE.DoubleSide,
});
const waterNd = new THREE.ShaderMaterial({
  vertexShader: `varying float vD; void main(){ vec4 mv = modelViewMatrix*vec4(position,1.); vD=-mv.z; gl_Position=projectionMatrix*mv; }`,
  fragmentShader: `varying float vD; void main(){ gl_FragColor=vec4(.5,1.,.5,vD); }`,
});

// ---------- helpers ----------
const add = (geo, mat, x = 0, y = 0, z = 0, parent = scene, opts = {}) => {
  const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = opts.cast ?? true; m.receiveShadow = true; parent.add(m); return m;
};
const box = (w, h, d) => new THREE.BoxGeometry(w, h, d);
const uvScale = (geo, su, sv) => { const uv = geo.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * su, uv.getY(i) * sv); return geo; };
/** box with world-scaled UVs per face (texel density 1 tile per `t` metres) */
const tbox = (w, h, d, t = 2) => {
  const g = box(w, h, d), uv = g.attributes.uv;
  const dims = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
  for (let f = 0; f < 6; f++) for (let k = 0; k < 4; k++) { const i = f * 4 + k; uv.setXY(i, uv.getX(i) * dims[f][0] / t, uv.getY(i) * dims[f][1] / t); }
  return g;
};

// ---------- sky ----------
const skyU = { top: { value: new THREE.Color() }, hor: { value: new THREE.Color() }, sunDir: { value: new THREE.Vector3() }, sunCol: { value: new THREE.Color() }, sunSize: { value: 0 } };
const sky = new THREE.Mesh(new THREE.SphereGeometry(1200, 32, 16), new THREE.ShaderMaterial({
  uniforms: skyU, side: THREE.BackSide, depthWrite: false, fog: false,
  vertexShader: `varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.); }`,
  fragmentShader: `uniform vec3 top, hor, sunDir, sunCol; uniform float sunSize; varying vec3 vP;
    void main(){ float h = clamp(vP.y,0.,1.); vec3 c = mix(hor, top, pow(h, .55)); if(vP.y<0.) c = hor;
      float s = dot(normalize(vP), normalize(sunDir)); c += sunCol * (smoothstep(1.-sunSize, 1.-sunSize*.6, s) + .35*pow(max(s,0.), 24.)*step(.001,sunSize));
      gl_FragColor = vec4(c,1.); }`,
}));
sky.userData.sky = true; scene.add(sky);

// ---------- lights ----------
const hemi = new THREE.HemisphereLight('#ffffff', '#ffffff', 1); scene.add(hemi);
const sun = new THREE.DirectionalLight('#ffffff', 2); sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048); sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.03; sun.shadow.radius = 2;
scene.add(sun); scene.add(sun.target);
scene.fog = new THREE.Fog('#ffffff', 40, 600);

// ---------- world: "The Ice That Sailed to India" ----------
const DECK = 0; // ground height everywhere
const PL = PLACES;
const world = new THREE.Group(); scene.add(world);
const waterU = { t: { value: 0 }, deep: { value: new THREE.Color('#2f6f8f') }, shal: { value: new THREE.Color('#5fa8bf') }, glint: { value: new THREE.Color('#e9f6ff') } };
const waterMat = new THREE.ShaderMaterial({
  uniforms: { ...THREE.UniformsUtils.clone(THREE.UniformsLib.fog), ...waterU }, fog: true,
  vertexShader: `#include <fog_pars_vertex>
    varying vec3 vW; void main(){ vec4 w = modelMatrix*vec4(position,1.); vW = w.xyz; vec4 mvPosition = viewMatrix*w; gl_Position = projectionMatrix*mvPosition;
    #include <fog_vertex>
    }`,
  fragmentShader: `#include <fog_pars_fragment>
    uniform float t; uniform vec3 deep, shal, glint; varying vec3 vW;
    float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
    float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f); return mix(mix(hash(i),hash(i+vec2(1,0)),f.x), mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x), f.y); }
    void main(){ vec2 p = vW.xz*vec2(.35,.12) + vec2(0., -t*.25);
      float n = noise(p) * .6 + noise(p*2.3 + 7.) * .4; float edge = smoothstep(10., 17., 0.);
      vec3 c = mix(deep, shal, .35 + .4*n + .4*edge);
      float streak = smoothstep(.72, .78, noise(vW.xz*vec2(.8,.09) + vec2(0., -t*.6))) * (1.-edge*.5);
      c = mix(c, glint, streak*.75);
      gl_FragColor = vec4(c,1.);
      #include <fog_fragment>
    }`,
});
const water = new THREE.Mesh(new THREE.PlaneGeometry(1400, 1400), waterMat); water.rotation.x = -Math.PI / 2; water.position.y = 0;
water.userData.nd = waterNd; water.receiveShadow = false; scene.add(water);
const seaPlane = (cx, cz, w, d, y) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), waterMat); m.rotation.x = -Math.PI / 2; m.position.set(cx, y, cz); m.userData.nd = waterNd; m.receiveShadow = false; scene.add(m); return m; };
scene.remove(water); // the template's single river plane is replaced by one plane per zone
// materials for this story
const sMat = (c, extra = {}) => new THREE.MeshToonMaterial({ gradientMap: grad, color: c, ...extra });
const MM = { snow: sMat('#eef2f7'), pond: sMat('#b9deee'), cut: sMat('#36657f'), ice: sMat('#c4e6f4'), sand: sMat('#dcc592'), saw: sMat('#e8c98c', { emissive: new THREE.Color('#7a5a2a') }), plankD: sMat('#5a3a22'), hull: sMat('#3d5688', { emissive: new THREE.Color('#18233a') }),
  cabin: sMat('#c9a56a'), sail: sMat('#efe5cb', { side: THREE.DoubleSide, emissive: new THREE.Color('#b8a888') }), jacket: sMat('#f08a2c'), cloth: sMat('#f4f0e6'), glass: sMat('#bfe8f6'),
  roof: sMat('#b5653f', { side: THREE.DoubleSide }), wall: sMat('#efe3c8', { side: THREE.DoubleSide }), dark: sMat('#2a2230'), pine: sMat('#4f7a4a'), oak: sMat('#6a9a45') };
const patchMat = (base, w, d, scale = 0.25) => { const m = base.clone(); m.map = base.map.clone(); m.map.repeat.set(w * scale, d * scale); m.map.needsUpdate = true; return m; };
const ground = (mat, cx, cz, w, d, y = -0.02) => { const m = add(new THREE.PlaneGeometry(w, d), mat, cx, y, cz, world, { cast: false }); m.rotation.x = -Math.PI / 2; return m; };
const disc = (mat, cx, cz, r, y) => { const m = add(new THREE.CircleGeometry(r, 48), mat, cx, y, cz, world, { cast: false }); m.rotation.x = -Math.PI / 2; return m; };
const iceStack = (parent, x0, y0, z0, nx, nz, l0, l1) => { for (let l = l0; l < l1; l++) for (let i = 0; i < nx; i++) for (let k = 0; k < nz; k++) add(box(0.9, 0.5, 0.6), MM.ice, x0 + i * 0.92 + 0.45, y0 + l * 0.52 + 0.25, z0 + k * 0.62 + 0.3, parent); };
const tree = (x, z, h = 6, kind = 'pine') => { const g = new THREE.Group(); g.position.set(x, 0, z); world.add(g); add(new THREE.CylinderGeometry(0.18, 0.26, h * 0.35, 6), M.trunk, 0, h * 0.175, 0, g);
  if (kind === 'pine') { add(new THREE.ConeGeometry(h * 0.2, h * 0.8, 8), MM.pine, 0, h * 0.62, 0, g); } else { const c = add(new THREE.SphereGeometry(h * 0.32, 10, 8), MM.oak, 0, h * 0.62, 0, g); c.scale.y = 0.9; } };
const hullGeo = (len, wid, hgt, y0) => { const sh = new THREE.Shape(); sh.moveTo(-wid / 2, len / 2); sh.lineTo(wid / 2, len / 2); sh.lineTo(wid / 2, -len * 0.18); sh.lineTo(0, -len / 2); sh.lineTo(-wid / 2, -len * 0.18); sh.closePath();
  const g = new THREE.ExtrudeGeometry(sh, { depth: hgt, bevelEnabled: false }); g.rotateX(-Math.PI / 2); g.translate(0, y0, 0); return g; };
/** the brig Tuscany: two masts, three square sails each, deck, rails, stern cabin; bow +z */
const makeShip = () => {
  const g = new THREE.Group(); scene.add(g);
  add(hullGeo(26, 7, 3.3, -1.5), MM.hull, 0, 0, 0, g);
  add(tbox(6.4, 0.08, 22, 2), M.plank, 0, 1.82, -1.5, g);
  for (const s of [-1, 1]) add(box(0.1, 0.9, 22), M.wood, s * 3.3, 2.25, -1.5, g);
  for (const z of [-4, 5]) {
    add(box(0.36, 15.2, 0.36), M.wood, 0, 9.4, z, g);
    for (const [y, w, h] of [[4.0, 8.0, 4.2], [9.0, 6.6, 3.8], [13.2, 4.6, 3.0]]) { add(box(w, 0.15, 0.2), M.wood, 0, y + h + 0.07, z, g); add(box(w - 0.4, h, 0.08), MM.sail, 0, y + h / 2, z, g); }
  }
  add(box(0.3, 0.3, 6), M.wood, 0, 2.05, 12, g);
  add(box(5.6, 2.4, 4), MM.cabin, 0, 3.05, -10.5, g);
  return g;
};
const mooredShip = makeShip(); mooredShip.position.set(PL.BOSTON[0] - 8, 0, PL.BOSTON[2] - 46); mooredShip.rotation.y = Math.PI / 2;
const seaShip = makeShip(); seaShip.visible = false;

// ---- BOSTON: snow, frozen pond with a cut channel, ice sleds, wharf, harbour ----
{
  const B = PL.BOSTON, W0 = PL.WHARF;
  ground(MM.snow, B[0], B[2] + 730, 3000, 1540);
  disc(MM.pond, B[0], B[2], 26, 0.02);
  const ch = add(new THREE.PlaneGeometry(8, 10), MM.cut, B[0] + 1, 0.03, B[2] + 13, world, { cast: false }); ch.rotation.x = -Math.PI / 2;
  for (let i = 0; i < 5; i++) add(box(1.1, 0.5, 0.8), MM.ice, B[0] - 1.8 + i * 1.5, 0.28, B[2] + 10.4 + (i % 2) * 2.4, world);
  for (const [x, z] of [[-8, 0.5], [9.5, 2.2]]) { add(box(2.2, 0.12, 1.6), M.wood, W0[0] + x, 0.06, W0[2] + z, world); iceStack(world, W0[0] + x - 0.9, 0.12, W0[2] + z - 0.62, 2, 2, 0, 3); }
  add(tbox(28, 0.15, 10, 2), M.plank, W0[0], -0.075, W0[2] - 0.5, world);
  for (let x = -13; x <= 13; x += 4) add(new THREE.CylinderGeometry(0.25, 0.25, 2.4, 8), M.beam, W0[0] + x, -0.5, W0[2] - 5.7, world);
  ['#efe6c8', '#d8b86a', '#2b2b30', '#7a4f33'].forEach((col, k) => { const m = add(new THREE.SphereGeometry(0.62, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), sMat(col), W0[0] - 3 + 2 * k, 0, W0[2], world); m.scale.y = 0.7; });
  add(new THREE.SphereGeometry(1.15, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2), MM.saw, W0[0] + 5, 0, W0[2], world).scale.y = 0.8;
  for (let k = 0; k < 14; k++) { const a = (k / 14) * Math.PI * 2 + 0.2, z = B[2] + Math.sin(a) * 36 + 10; if (z < B[2] + 12) continue; tree(B[0] + Math.cos(a) * 36, z, 6 + (k % 4), 'pine'); }
  seaPlane(B[0], B[2] - 790, 3000, 1500, -0.9);
}

// ---- CALCUTTA: sand, cobbled street, houses, verandah, ice house, tables ----
{
  const C = PL.CAL;
  ground(patchMat(M.dirt, 3000, 3000, 0.2), C[0], C[2], 3000, 3000);
  const st = add(new THREE.PlaneGeometry(10, 100), M.dirt, C[0], 0.012, C[2], world, { cast: false }); st.rotation.x = -Math.PI / 2;
  const hs = (x, z, w, d, h, rot, mat) => { const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = rot; world.add(g);
    add(tbox(w, h, d, 2), mat, 0, h / 2, 0, g); const rf = add(new THREE.ConeGeometry(Math.hypot(w, d) / 2 + 0.5, 1.8, 4), MM.roof, 0, h + 0.9, 0, g); rf.rotation.y = Math.PI / 4; rf.scale.set(w / Math.hypot(w, d) * 1.414, 1, d / Math.hypot(w, d) * 1.414);
    add(box(0.9, 1.8, 0.1), M.door, 0, 0.9, d / 2 + 0.03, g, { cast: false }); for (const s of [-1, 1]) add(box(0.6, 0.7, 0.1), M.window, s * w * 0.3, h * 0.62, d / 2 + 0.03, g, { cast: false }); return g; };
  for (let k = 0, z = -34; z <= 34; k++, z += 9) { hs(C[0] - 11, C[2] + z, 8, 8, k % 2 ? 7 : 8.4, Math.PI / 2, k % 2 ? M.plaster : M.plaster2); hs(C[0] + 11, C[2] + z + 4, 8, 8, k % 2 ? 8.4 : 7, -Math.PI / 2, k % 2 ? M.plaster2 : M.plaster); }
  add(box(3.6, 0.12, 3.6), M.plank, C[0] - 5.2, 1.94, C[2] + 2.0, world); // verandah where the bishop stands
  for (const z of [0.3, 3.7]) add(box(0.14, 3.4, 0.14), M.wood, C[0] - 3.5, 1.7, C[2] + z, world);
  add(box(0.14, 0.1, 3.6), M.wood, C[0] - 3.5, 2.95, C[2] + 2.0, world);
  add(tbox(8, 6, 8, 3), M.stone, C[0] + 21, 3, C[2] - 10, world); add(box(0.15, 3.2, 2), MM.dark, C[0] + 16.95, 1.6, C[2] - 10, world); // the ice house
  add(box(3.4, 0.08, 1.4), MM.cloth, C[0], 0.78, C[2] + 6, world);
  for (const [x, z] of [[-1.5, 5.4], [1.5, 5.4], [-1.5, 6.6], [1.5, 6.6]]) add(box(0.1, 0.74, 0.1), M.wood, C[0] + x, 0.37, C[2] + z, world);
  for (let k = 0; k < 8; k++) add(box(0.1, 0.18, 0.1), MM.glass, C[0] - 1.3 + k * 0.4, 0.91, C[2] + 5.6 + (k % 2) * 0.7, world);
  add(box(0.7, 0.6, 0.5), MM.ice, C[0], 1.12, C[2] + 6, world);
  for (let k = 0; k < 12; k++) tree(C[0] + (k % 2 ? 1 : -1) * (30 + (k >> 1) * 4), C[2] + ((k * 13) % 50) - 25, 8, 'oak');
}

// ---- HOLD: open-fronted room, 0.46 m of sawdust between two plank layers on each side ----
const holdTop = new THREE.Group(); world.add(holdTop);
{
  const H = PL.HOLD;
  ground(M.plank.clone(), H[0], H[2], 28, 28, 0);
  add(box(6.4, 4, 0.2), M.wood, H[0], 2, H[2] + 7.6, world);
  for (const s of [-1, 1]) { const x = (a, c) => H[0] + s * (a + c) / 2; const L = 9.8, zc = H[2] + 2.7;
    add(box(0.06, 3.5, L), MM.plankD, x(2.44, 2.5), 1.75, zc, world); add(box(0.46, 3.5, L), MM.saw, x(2.5, 2.96), 1.75, zc, world); add(box(0.06, 3.5, L), MM.plankD, x(2.96, 3.02), 1.75, zc, world); }
  iceStack(world, H[0] + 0.45, 0, H[2] - 0.6, 2, 9, 0, 3);
  iceStack(holdTop, H[0] + 0.45, 0, H[2] - 0.6, 2, 9, 3, 6);
  add(new THREE.CylinderGeometry(0.13, 0.15, 1.3, 10), M.stone, H[0] - 1.9, 0.65, H[2], world); add(box(1.0, 0.08, 0.1), M.wood, H[0] - 1.9, 1.29, H[2], world);
  const pd = add(new THREE.PlaneGeometry(1.2, 1.6), MM.cut, H[0] - 0.9, 0.012, H[2] + 0.1, world, { cast: false }); pd.rotation.x = -Math.PI / 2;
}

// ---- SEA: open water only (the second Tuscany sails here) ----
seaPlane(PL.SEA[0], PL.SEA[2], 1400, 1400, -0.5);

// ---- JACKET analogy set ----
{
  const J = PL.JACKET;
  ground(patchMat(M.grass, 3000, 3000), J[0], J[2], 3000, 3000);
  add(box(1.8, 1.6, 1.8), MM.ice, J[0], 0.8, J[2] + 3, world);
  for (let k = 0; k < 14; k++) { const a = (k / 14) * Math.PI * 2; for (const y of [0.3, 0.8, 1.3]) { const s = add(new THREE.SphereGeometry(0.42, 12, 8), MM.jacket, J[0] + Math.cos(a) * 1.15, y, J[2] + 3 + Math.sin(a) * 1.15, world); s.scale.y = 0.72; } }
  for (let k = 0; k < 6; k++) { const s = add(new THREE.SphereGeometry(0.5, 12, 8), MM.jacket, J[0] + (k % 3 - 1) * 0.6, 1.62, J[2] + 2.5 + (k >> 1) * 0.5, world); s.scale.y = 0.4; }
  for (let k = 0; k < 10; k++) tree(J[0] + (k % 2 ? 1 : -1) * (14 + (k >> 1) * 3), J[2] + 8 + k * 2, 7, 'oak');
}

// ---- WALDEN beside the GANGES ----
{
  const Wd = PL.WALDEN;
  ground(MM.snow, Wd[0] - 739, Wd[2], 1522, 3000);
  disc(MM.pond, Wd[0], Wd[2], 22, 0.02);
  for (const s of [-1, 1]) ground(patchMat(M.grass, 1500, 1500), Wd[0] + 772, Wd[2] + s * 764, 1500, 1500);
  seaPlane(Wd[0] + 772, Wd[2], 1500, 28, -0.5);
  for (let k = 0; k < 10; k++) for (const s of [-1, 1]) tree(Wd[0] + 30 + k * 11, Wd[2] + s * (18 + (k % 3) * 3), 8 + (k % 3), k % 2 ? 'oak' : 'pine');
  for (let k = 0; k < 8; k++) tree(Wd[0] - 30 - k * 6, Wd[2] + ((k * 23) % 40) - 20, 8, 'pine');
}

// ---- CHENNAI: the round Madras ice house ----
{
  const K = PL.CHENNAI;
  ground(MM.sand, K[0], K[2], 3000, 3000);
  add(new THREE.CylinderGeometry(7.4, 7.6, 0.5, 32), M.stone, K[0], 0.25, K[2], world);
  add(new THREE.CylinderGeometry(7, 7, 5.5, 32, 1, true), MM.wall, K[0], 3.25, K[2], world);
  add(new THREE.ConeGeometry(8.3, 3.4, 32), MM.roof, K[0], 7.7, K[2], world);
  for (let k = 0; k < 10; k++) { const a = (k / 10) * Math.PI * 2 + 0.15; add(box(1, 2.5, 0.15), MM.dark, K[0] + Math.sin(a) * 7.0, 2.15, K[2] + Math.cos(a) * 7.0, world).rotation.y = a; }
  for (let k = 0; k < 8; k++) tree(K[0] + Math.cos(k * 0.8) * 30, K[2] + Math.sin(k * 0.8) * 30, 8, 'oak');
}

// clouds: painted billboards far away (no fog, no ink)
const clouds = [];
{ const r = P.rng(90);
  for (let i = 0; i < 14; i++) {
    const c = document.createElement('canvas'); c.width = 600; c.height = 400; const pen = new T.Pen(c.getContext('2d')); pen.ol = 0;
    pen.g.translate(300, 200); pen.g.scale(1.4, 1.2); pen.g.translate(-300, -200); T.fxCloud(pen, i + 1);
    const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 0.667), new THREE.MeshBasicMaterial({ map: P.tex(c), transparent: true, fog: false, depthWrite: false }));
    const a = r() * Math.PI * 2, d = 650 + r() * 250; m.position.set(Math.cos(a) * d, 120 + r() * 160, Math.sin(a) * d); m.scale.setScalar(160 + r() * 140);
    m.userData.ndSkip = true; m.renderOrder = -1; m.userData.p0 = m.position.clone(); scene.add(m); clouds.push(m);
  } }

// ---------- cards ----------
const CW = 1200, CH = 2000, CM = 2.25; // canvas px, card height in metres (design 600x1000 -> 2.25 m)
const cardGeo = new THREE.PlaneGeometry(CM * 0.6, CM); cardGeo.translate(0, CM / 2 - CM * 0.025, 0);
const blobTex = P.tex(P.radial('20,14,30', 0.6));
class Card {
  constructor(scale = 1) {
    [this.c, this.g] = (() => { const c = document.createElement('canvas'); c.width = CW; c.height = CH; return [c, c.getContext('2d')]; })();
    this.t = new THREE.CanvasTexture(this.c); this.t.colorSpace = THREE.SRGBColorSpace; this.t.anisotropy = 4;
    this.mat = new THREE.MeshBasicMaterial({ map: this.t, transparent: true, alphaTest: 0.02, side: THREE.DoubleSide, fog: true });
    this.mesh = new THREE.Mesh(cardGeo, this.mat); this.mesh.userData.nd = cardNd(this.t); this.mesh.castShadow = true;
    this.mesh.customDepthMaterial = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: this.t, alphaTest: 0.5 });
    this.blob = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: blobTex, transparent: true, depthWrite: false, fog: true }));
    this.blob.rotation.x = -Math.PI / 2; this.blob.userData.ndSkip = true; this.blob.renderOrder = 1;
    scene.add(this.mesh); scene.add(this.blob); this.key = ''; this.mesh.visible = this.blob.visible = false;
  }
  draw(key, fn) {
    if (key === this.key) return; this.key = key;
    const g = this.g; g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, CW, CH); g.setTransform(CW / 600, 0, 0, CH / 1000, 0, 0);
    const p = new T.Pen(g); fn(p); this.t.needsUpdate = true;
  }
}
const cards = []; const getCard = (i) => cards[i] || (cards[i] = new Card());

// ---------- render targets & post ----------
const rtColor = new THREE.WebGLRenderTarget(W, H, { samples: 4, type: THREE.HalfFloatType });
const rtNd = new THREE.WebGLRenderTarget(W, H, { type: THREE.HalfFloatType, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter });
const rtInk = new THREE.WebGLRenderTarget(W, H, { type: THREE.HalfFloatType });
const fsCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1), fsGeo = new THREE.PlaneGeometry(2, 2);
const fs = (mat) => { const s = new THREE.Scene(); s.add(new THREE.Mesh(fsGeo, mat)); return s; };
const inkU = { col: { value: rtColor.texture }, nd: { value: rtNd.texture }, res: { value: new THREE.Vector2(W, H) }, px: { value: 1.6 }, fogCol: { value: new THREE.Color() },
  sat: { value: 1.08 }, lift: { value: new THREE.Color(0, 0, 0) }, gain: { value: new THREE.Color(1, 1, 1) }, vig: { value: 0.22 }, flash: { value: 0 } };
const inkScene = fs(new THREE.ShaderMaterial({ uniforms: inkU, vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=vec4(position.xy,0.,1.); }`,
  fragmentShader: `uniform sampler2D col, nd; uniform vec2 res; uniform float px, sat, vig, flash; uniform vec3 fogCol, lift, gain; varying vec2 vUv;
  float edgeAt(vec2 uv, float r){
    vec4 c = texture2D(nd, uv); if (dot(c.rgb,c.rgb) < .01) return 0.; float d = c.a; vec3 n = c.rgb*2.-1.;
    float e = 0.; float rr = r * clamp(7./d, .62, 1.25);
    for (int i=0;i<16;i++){ float a = float(i)*.785398 + (i>7 ? .39 : 0.); float k = i>7 ? .5 : 1.;
      vec2 o = vec2(cos(a), sin(a))*rr*k/res; vec4 s = texture2D(nd, uv+o);
      float ds = s.a; bool card = dot(s.rgb,s.rgb) < .01;
      if (card && ds > 0.) continue;            // character cards: never outlined by the world ink
      if (card) ds = 1e4;                        // sky
      vec3 ns = s.rgb*2.-1.;
      e = max(e, smoothstep(.006, .02, (ds - d)/d));                           // depth jump, near side only
      if (!card && abs(ds-d)/d < .06) e = max(e, smoothstep(.88, .72, dot(n, ns)) * .9); // crease
    }
    return e * (1. - smoothstep(140., 520., d)*.8);
  }
  void main(){
    vec3 c = texture2D(col, vUv).rgb;
    float e = edgeAt(vUv, px);
    c = mix(c, vec3(.012,.01,.014), e);
    if (flash < -0.5) c = vec3(e);
    float l = dot(c, vec3(.299,.587,.114)); c = mix(vec3(l), c, sat);
    c = c*gain + lift;
    vec2 q = vUv-.5; c *= 1. - vig*dot(q*vec2(1.,.75), q*vec2(1.,.75))*2.2;
    c = mix(c, vec3(1.), flash);
    gl_FragColor = vec4(c,1.); }` }));
const dofU = { src: { value: rtInk.texture }, nd: { value: rtNd.texture }, res: { value: new THREE.Vector2(W, H) }, focus: { value: 5 }, cinf: { value: 0 }, near: { value: 1 } };
const dofScene = fs(new THREE.ShaderMaterial({ uniforms: dofU, vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=vec4(position.xy,0.,1.); }`,
  fragmentShader: `uniform sampler2D src, nd; uniform vec2 res; uniform float focus, cinf, near; varying vec2 vUv;
  float coc(vec2 uv){ float d = texture2D(nd, uv).a; if (d <= 0.) d = 2000.; float k = 1. - focus/d; return k > 0. ? cinf*k : min(-k*cinf*near, cinf*1.4); }
  void main(){
    float c0 = coc(vUv);
    if (cinf < .5 || c0 < .6) { gl_FragColor = linearToOutputTexel(vec4(texture2D(src, vUv).rgb, 1.)); return; }
    vec3 acc = vec3(0.); float wsum = 0.;
    for (int i=0;i<48;i++){ float fi = float(i); float r = sqrt((fi+.5)/48.); float a = fi*2.39996;
      vec2 o = vec2(cos(a), sin(a))*r*c0/res; float cs = coc(vUv+o);
      float w = smoothstep(r*c0-1.5, r*c0+.5, cs + .5);
      acc += texture2D(src, vUv+o).rgb*w; wsum += w; }
    gl_FragColor = linearToOutputTexel(vec4(acc/max(wsum,1e-3), 1.)); }` }));
// final copy with sRGB handled by the renderer output (we render to screen with linear->sRGB in the shader chunk)
dofScene.children[0].material.toneMapped = false;

// ---------- per-frame state ----------
const tmpV = new THREE.Vector3();
function applyLight(L, f) {
  hemi.color.set(L.sky); hemi.groundColor.set(L.ground); hemi.intensity = L.hemi;
  sun.color.set(L.sun); sun.intensity = L.sunI;
  scene.fog.color.set(L.fog); scene.fog.near = L.fogNear; scene.fog.far = L.fogFar;
  skyU.top.value.set(L.skyTop); skyU.hor.value.set(L.skyHor); skyU.sunCol.value.set(L.sunDisc || '#000'); skyU.sunSize.value = L.sunSize || 0;
  inkU.sat.value = L.sat; inkU.gain.value.set(L.gain || '#ffffff'); inkU.lift.value.set(L.lift || '#000000');
  waterU.deep.value.set(L.waterDeep); waterU.shal.value.set(L.waterShal); waterU.glint.value.set(L.glint);
}
function placeSun(L, focus) {
  // sun direction from azimuth/elevation in world space
  const az = rx(L.az), el = rx(L.el); tmpV.set(Math.cos(el) * Math.cos(az), Math.sin(el), Math.cos(el) * Math.sin(az));
  skyU.sunDir.value.copy(tmpV);
  sun.position.copy(focus).addScaledVector(tmpV, 80); sun.target.position.copy(focus);
  const ext = L.shadowExt || 30, sc = sun.shadow.camera; sc.left = -ext; sc.right = ext; sc.top = ext; sc.bottom = -ext; sc.near = 1; sc.far = 200; sc.updateProjectionMatrix();
}

function worldState(S, f) {
  seaShip.visible = !!S.seaShip;
  if (S.seaShip) { seaShip.position.set(S.seaShip[0], S.seaShip[1], S.seaShip[2]); seaShip.rotation.z = 0.025 * Math.sin(f / 30 * 1.3); }
  holdTop.visible = !!S.holdTop;
  waterU.t.value = f / 30;
}

function drawActors(list, cam) {
  cards.forEach((c) => { c.mesh.visible = c.blob.visible = false; });
  list.forEach((a, i) => {
    const c = getCard(i);
    c.draw(a.key, a.draw);
    c.mesh.visible = true; c.mesh.position.set(a.x, a.y, a.z);
    const s = a.s || 1; c.mesh.scale.set(s * (a.flip ? -1 : 1), s, s);
    c.mesh.rotation.set(0, Math.atan2(cam.position.x - a.x, cam.position.z - a.z) + (a.yaw || 0), a.roll || 0);
    c.mat.color.set(a.tint || '#ffffff'); c.mat.opacity = a.alpha ?? 1;
    c.mesh.castShadow = a.shadow !== false;
    c.mesh.renderOrder = a.order || 2;
    if (a.blob !== false && (a.ground ?? a.y) < 4) { c.blob.visible = true; c.blob.position.set(a.x, (a.ground ?? a.y) + 0.02, a.z); c.blob.scale.set(0.95 * s, 0.6 * s, 1); }
  });
}

const swapForNd = (on) => {
  scene.traverse((o) => {
    if (!o.isMesh) return;
    if (on) {
      o.userData.mat0 = o.material;
      if (o.userData.ndSkip) { o.userData.vis0 = o.visible; o.visible = false; return; }
      if (o === sky || o.userData.sky) { o.userData.vis0 = o.visible; o.visible = false; return; }
      o.material = o.userData.nd || ndMat;
    } else {
      o.material = o.userData.mat0; if (o.userData.vis0 !== undefined) { o.visible = o.userData.vis0; delete o.userData.vis0; }
    }
  });
};

window.renderFrame = (f) => {
  const S = shotAt(f), L = lightFor(S, f), C = camAt(f);
  applyLight(L, f);
  camera.position.set(...C.pos); camera.up.set(0, 1, 0); camera.lookAt(...C.look); camera.rotateZ(rx(C.roll || 0));
  camera.fov = C.fov; camera.updateProjectionMatrix(); camera.updateMatrixWorld();
  const W_ = worldAt(f); worldState(W_, f);
  placeSun(L, new THREE.Vector3(...(C.shadowAt || C.look)));
  drawActors([...actorsAt(f, T), ...fxAt(f, T)], camera);
  sky.position.copy(camera.position);
  for (const c of clouds) { c.position.set(camera.position.x + c.userData.p0.x, c.userData.p0.y, camera.position.z + c.userData.p0.z); c.quaternion.copy(camera.quaternion); }
  // pass A: colour
  renderer.setRenderTarget(rtColor); renderer.setClearColor(0x000000, 1); renderer.clear(); renderer.render(scene, camera);
  // pass B: normal + depth
  const fog = scene.fog; scene.fog = null; const sm = renderer.shadowMap.enabled; renderer.shadowMap.enabled = false; renderer.shadowMap.autoUpdate = false;
  swapForNd(true); renderer.setRenderTarget(rtNd); renderer.setClearColor(0x000000, 0); renderer.clear(); renderer.render(scene, camera); swapForNd(false);
  scene.fog = fog; renderer.shadowMap.enabled = sm; renderer.shadowMap.autoUpdate = true;
  if (window.DEBUG_ND) { const dm = new THREE.MeshBasicMaterial({ map: rtNd.texture }); const ds = fs(dm); renderer.setRenderTarget(null); renderer.render(ds, fsCam); return true; }
  // ink + grade
  const D = dofAt(f);
  inkU.px.value = 2.5; inkU.flash.value = window.DEBUG_E ? -1 : (C.flash || 0); inkU.vig.value = L.vig ?? 0.22;
  renderer.setRenderTarget(rtInk); renderer.render(inkScene, fsCam);
  // lens
  dofU.focus.value = D.focus; dofU.cinf.value = D.cinf; dofU.near.value = D.near ?? 1;
  renderer.setRenderTarget(null); renderer.render(dofScene, fsCam);
  return true;
};
window.TOTAL = TOTAL;
window.ready = true;