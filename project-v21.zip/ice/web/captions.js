// word-by-word captions: [startFrame, endFrame, text] in story (audio) frames
export const CAPTIONS = [
  [80, 126, "In 1833,"], [127, 144, "a man from"], [145, 179, "Boston loaded a"], [180, 210, "frozen pond onto"], [211, 234, "a ship."],
  [238, 256, "Then he sent"], [257, 292, "it to India."], [295, 321, "Calcutta."], [324, 354, "A city that"], [355, 397, "never sees frost."],
  [398, 423, "That summer,"], [424, 447, "a bishop there"], [448, 465, "wrote home that"], [466, 482, "the heat was"], [483, 523, "suffocating."],
  [529, 559, "Frederic Tudor had"], [560, 594, "tried this before."], [595, 616, "His first ice"], [617, 644, "melted on the"], [645, 663, "dock."],
  [664, 690, "So he tested"], [691, 699, "rice."], [698, 711, "Chaff."], [712, 731, "Coal dust."], [732, 740, "Bark."],
  [740, 777, "Sawdust won."], [780, 796, "Then a ship"], [797, 825, "appeared with"], [826, 854, "nothing to carry"], [855, 878, "out to India."],
  [880, 902, "So he filled"], [903, 945, "it with winter."], [968, 982, "The ship got"], [983, 1002, "double walls,"], [1003, 1020, "with sawdust"],
  [1021, 1052, "packed between them,"], [1053, 1072, "half a metre"], [1073, 1086, "thick."], [1090, 1112, "Every day,"], [1113, 1134, "the crew pumped"],
  [1135, 1168, "out the meltwater."], [1172, 1188, "May."], [1191, 1215, "One hundred eighty"], [1216, 1235, "tons of ice."], [1238, 1255, "Half a world"],
  [1256, 1278, "away."], [1282, 1310, "Four months at sea,"], [1311, 1334, "mostly through the"], [1335, 1346, "tropics."], [1349, 1364, "Luckily,"],
  [1365, 1392, "the ship arrived."], [1394, 1416, "Unluckily,"], [1417, 1456, "eighty tons of"], [1457, 1482, "ice did not."], [1485, 1500, "So why did"],
  [1501, 1534, "the rest survive?"], [1536, 1558, "Sawdust is full"], [1559, 1602, "of tiny pockets"], [1603, 1620, "of air,"], [1621, 1634, "and air is"],
  [1635, 1650, "terrible at"], [1651, 1665, "passing heat"], [1666, 1684, "along."], [1688, 1706, "It's a puffy"], [1707, 1718, "jacket,"],
  [1719, 1738, "wrapped around a"], [1739, 1756, "pond."], [1760, 1788, "That September,"], [1789, 1815, "Calcutta's tables"], [1816, 1832, "glittered with"],
  [1833, 1846, "ice."], [1848, 1862, "Soon ships came"], [1863, 1882, "regularly."], [1884, 1902, "Ice houses rose"], [1903, 1932, "in Calcutta,"],
  [1933, 1966, "Bombay and Madras."], [1968, 1982, "One still stands"], [1983, 2006, "in Chennai."], [2010, 2034, "Within fourteen years,"], [2035, 2048, "ships were"],
  [2049, 2076, "delivering nearly"], [2077, 2092, "three thousand"], [2093, 2114, "tons a year."], [2116, 2128, "And Thoreau,"], [2129, 2146, "watching ice crews"],
  [2147, 2170, "at Walden Pond,"], [2171, 2190, "noticed something."], [2191, 2196, "The water of"], [2197, 2199, "America's most"], [2200, 2201, "famous pond was"],
  [2202, 2202, "mingling with the"], [2203, 2203, "Ganges."]
];
