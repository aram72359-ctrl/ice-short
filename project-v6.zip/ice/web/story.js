// "The Ice That Sailed to India": shot plan for the cartoon-short-kit engine, timed to voice.wav (77.72 s, padded to 2342 frames at 30 fps).
// Beat frames come from aligning SCRIPT.md to the pauses in the voice (phrases.json); replace them if you re-run word timings.
import { M, camFromKeys, blinkAt, idle, q, clamp, lerp, ramp } from './motion.js';
export const FPS = 30, TOTAL = 2204, DECK = 0; // last word ends at f2189; 15 frames of tail so the video ends on the climax
export const smooth = M.smooth;
// Zones are far apart so no zone ever shows in another's frame (camera far plane is 1500 m).
export const PLACES = {
  BOSTON: [0, 0, 0], WHARF: [0, 0, -34], CAL: [2000, 0, 0], HOLD: [4000, 0, 0], SEA: [6000, 0, 0],
  JACKET: [8000, 0, 0], WALDEN: [10000, 0, 0], CHENNAI: [12000, 0, 0],
};
const P = PLACES;
const A = (p, x, y, z) => [p[0] + x, p[1] + y, p[2] + z];
export const shipZ = (f) => -90 + (f - 1015) * 0.2; // the Tuscany at sea sails +z at 6 m/s

export const SHOTS = [
  { id: 1, a: 0, b: 237, light: 'day' },       // hook: frozen pond onto a ship
  { id: 2, a: 238, b: 423, light: 'golden' },  // Calcutta heat, the bishop
  { id: 3, a: 424, b: 553, light: 'day' },     // first ice melts
  { id: 4, a: 554, b: 664, light: 'day' },     // rice, chaff, coal, bark, sawdust
  { id: 5, a: 665, b: 822, light: 'day' },     // empty ship filled with winter
  { id: 6, a: 823, b: 1014, light: 'day' },    // double walls, the pump
  { id: 7, a: 1015, b: 1162, light: 'golden' },// four months at sea
  { id: 8, a: 1163, b: 1308, light: 'day' },   // luckily / unluckily
  { id: 9, a: 1309, b: 1591, light: 'night' }, // the puffy jacket
  { id: 10, a: 1592, b: 1739, light: 'golden' },// Calcutta tables glitter
  { id: 11, a: 1740, b: 2000, light: 'golden' },// ice houses, Chennai
  { id: 12, a: 2001, b: 2203, light: 'golden' },// Walden into the Ganges
];
export const shotAt = (f) => SHOTS.find((s) => f >= s.a && f <= s.b) || SHOTS[SHOTS.length - 1];

// ---------- lights ----------
export const LIGHTS = {
  // morning / day: bright, airy blue sky, warm cream highlights, soft warm-grey shadows
  day: { az: 140, el: 46, sky: '#dbe7f7', ground: '#8c7a6b', hemi: 1.2, sun: '#ffe6b8', sunI: 2.4, fog: '#e4eaf2', fogNear: 140, fogFar: 1000,
    skyTop: '#4a8de0', skyHor: '#dfe9f3', sat: 1.22, gain: '#fff6e6', lift: '#100c18', waterDeep: '#2c6c8c', waterShal: '#5aaec4', glint: '#fff3dc', vig: 0.2, shadowExt: 22 },
  // evening: golden-peach key, soft lavender/purple shadows
  golden: { az: 8, el: 9, sky: '#8d82c6', ground: '#5a4a8e', hemi: 1.05, sun: '#ffb36b', sunI: 2.8, fog: '#efb78f', fogNear: 110, fogFar: 900,
    skyTop: '#6f6eb0', skyHor: '#ffc27e', sunDisc: '#ffe3b0', sunSize: 0.0035, sat: 1.2, gain: '#ffeccc', lift: '#201838', waterDeep: '#3d5a86', waterShal: '#d99a6e',
    glint: '#ffd28a', vig: 0.26, shadowExt: 22 },
  // explanation beat: calm blue night, still lifted so nothing goes pitch black
  night: { az: 200, el: 30, sky: '#5a6fa8', ground: '#3a3f72', hemi: 1.1, sun: '#9fb8ff', sunI: 1.5, fog: '#34437a', fogNear: 60, fogFar: 600,
    skyTop: '#1b2a5c', skyHor: '#4a5f9c', sat: 1.15, gain: '#e8eeff', lift: '#0f1538', waterDeep: '#1c2c58', waterShal: '#3c5a90', glint: '#a8c4ff', vig: 0.3, shadowExt: 18 },
};
export const lightFor = (S, f) => ({ ...LIGHTS[S.light] });

// ---------- cameras ----------
// keys { f, pos, look, fov, roll (deg), ease }: smootherstep glides, 'easeOut' bursts for reveals/whips; every hold creeps.
const CAMS = {
  1: [
    { f: 0, pos: A(P.WHARF, 4.5, 2.2, 5), look: A(P.WHARF, -4, 1.6, -10), fov: 44 },
    { f: 90, pos: A(P.WHARF, 2.6, 1.6, 2.6), look: A(P.WHARF, -2, 1.5, -7), fov: 42 },
    { f: 182, pos: A(P.WHARF, 1.4, 1.3, -2.6), look: A(P.WHARF, 0.2, 1.0, 0), fov: 38, roll: -2.5, ease: 'easeOut' },
  ],
  2: [
    { f: 238, pos: A(P.CAL, 9, 5.5, -22), look: A(P.CAL, 0, 3.5, 4), fov: 42 },
    { f: 330, pos: A(P.CAL, -2.5, 3.1, -5), look: A(P.CAL, -4.5, 3.4, 2), fov: 36, roll: 2, ease: 'easeOut' },
  ],
  3: [
    { f: 424, pos: A(P.WHARF, 3, 1.5, -5.5), look: A(P.WHARF, 0, 1.4, 0), fov: 38 },
    { f: 527, pos: A(P.WHARF, 0.4, 0.9, -3.2), look: A(P.WHARF, 0, 0.12, 0.3), fov: 36, roll: -2, ease: 'easeOut' },
  ],
  4: [
    { f: 554, pos: A(P.WHARF, -3, 1.55, -4.6), look: A(P.WHARF, -3, 0.95, 0.4), fov: 40, roll: -2 },
    { f: 595, pos: A(P.WHARF, -1, 1.55, -4.6), look: A(P.WHARF, -1, 0.95, 0.4), fov: 40, roll: 2, ease: 'easeOut' },
    { f: 600, pos: A(P.WHARF, 1, 1.55, -4.6), look: A(P.WHARF, 1, 0.95, 0.4), fov: 40, roll: -2, ease: 'easeOut' },
    { f: 612, pos: A(P.WHARF, 3, 1.55, -4.6), look: A(P.WHARF, 3, 0.95, 0.4), fov: 40, roll: 2, ease: 'easeOut' },
    { f: 617, pos: A(P.WHARF, 5, 1.5, -4.8), look: A(P.WHARF, 5, 1.0, 0), fov: 38, roll: 0, ease: 'easeOut' },
  ],
  5: [
    { f: 665, pos: A(P.WHARF, 14, 3.5, 3), look: A(P.WHARF, -8, 2.2, -11), fov: 50 },
    { f: 822, pos: A(P.WHARF, 10, 3.2, 0), look: A(P.WHARF, -8, 2.4, -11), fov: 47 },
  ],
  6: [
    { f: 823, pos: A(P.HOLD, 3.7, 1.6, -6.4), look: A(P.HOLD, 2.8, 1.4, -2.0), fov: 40 },
    { f: 870, pos: A(P.HOLD, 3.2, 1.55, -5.0), look: A(P.HOLD, 2.8, 1.4, -2.0), fov: 33 },
    { f: 922, pos: A(P.HOLD, -2.2, 1.0, -4.2), look: A(P.HOLD, -1.2, 0.5, 0), fov: 36, roll: 1.7, ease: 'easeOut' },
  ],
  7: [
    { f: 1015, pos: [P.SEA[0] + 26, 8, shipZ(1015) - 6], look: [P.SEA[0], 2.5, shipZ(1015) + 6], fov: 44 },
    { f: 1126, pos: [P.SEA[0] + 14, 3.4, shipZ(1126) - 4], look: [P.SEA[0], 3, shipZ(1126) + 3], fov: 40, roll: -2.3 },
    { f: 1162, pos: [P.SEA[0] + 13, 3.3, shipZ(1162) - 3], look: [P.SEA[0], 3, shipZ(1162) + 3], fov: 38, roll: -2.3 },
  ],
  8: [
    { f: 1163, pos: A(P.HOLD, 0.4, 1.7, -8), look: A(P.HOLD, 0.5, 1.3, -0.5), fov: 40 },
    { f: 1231, pos: A(P.HOLD, -0.3, 1.2, -4.6), look: A(P.HOLD, 0.3, 0.9, -1.0), fov: 36, roll: 2.3, ease: 'easeOut' },
  ],
  9: [
    { f: 1309, pos: A(P.JACKET, 1.2, 1.5, -5.2), look: A(P.JACKET, 0, 1.3, 0), fov: 38 },
    { f: 1354, pos: A(P.JACKET, 0.3, 1.3, -2.6), look: A(P.JACKET, 0, 1.2, 0), fov: 34, roll: -2 },
    { f: 1430, pos: A(P.JACKET, -0.6, 1.4, -3.0), look: A(P.JACKET, 0.1, 1.2, 0), fov: 35, roll: 1.5 },
    { f: 1502, pos: A(P.JACKET, 13, 4.5, -9), look: A(P.JACKET, 4.5, 0.9, 3), fov: 44, roll: 2, ease: 'easeOut' },
  ],
  10: [
    { f: 1592, pos: A(P.CAL, 1.6, 2.0, -3.6), look: A(P.CAL, 0, 1.6, 6), fov: 38 },
    { f: 1656, pos: A(P.CAL, -1.6, 2.0, -1.8), look: A(P.CAL, 0.6, 1.2, 6.0), fov: 44, roll: 2 },
  ],
  11: [
    { f: 1740, pos: A(P.CHENNAI, 22, 6, -34), look: A(P.CHENNAI, 0, 3.5, 0), fov: 40 },
    { f: 1790, pos: A(P.CHENNAI, 19, 5.6, -30), look: A(P.CHENNAI, 0, 3.6, 0), fov: 39 },
    { f: 1855, pos: A(P.CHENNAI, 16, 5, -26), look: A(P.CHENNAI, 0, 3.8, 0), fov: 38, ease: 'easeOut' },
    { f: 1930, pos: A(P.CHENNAI, -4, 3.4, -24), look: A(P.CHENNAI, 0, 4, 0), fov: 38, roll: -1.5 },
    { f: 2000, pos: A(P.CHENNAI, -5, 3.3, -22), look: A(P.CHENNAI, 0, 3.8, 0), fov: 37 },
  ],
  12: [
    { f: 2001, pos: A(P.WALDEN, 8, 3.5, -9), look: A(P.WALDEN, 2.5, 1.2, -2), fov: 34 },
    { f: 2060, pos: A(P.WALDEN, 9, 3.8, -9.5), look: A(P.WALDEN, 3, 1.0, -1.5), fov: 35 },
    { f: 2090, pos: A(P.WALDEN, 9, 4, -10), look: A(P.WALDEN, 3, 1.0, -1), fov: 36 },
    { f: 2203, pos: A(P.WALDEN, 5, 5.5, -15), look: A(P.WALDEN, 30, 1.5, 0), fov: 46 },
  ],
};
// a key with ease 'easeOut' is a burst: the camera holds the previous pose, then arrives over `dur` frames (default 12)
const expand = (K) => {
  const out = [K[0]];
  for (let i = 1; i < K.length; i++) {
    const prev = out[out.length - 1], k = K[i];
    if (k.ease === 'easeOut') { const f0 = Math.max(prev.f, k.f - (k.dur || 12)); if (f0 > prev.f) out.push({ ...prev, f: f0, ease: 'smooth' }); }
    out.push(k);
  }
  return out;
};
for (const id of Object.keys(CAMS)) CAMS[id] = expand(CAMS[id]);
const KICKS = [{ f: 527, a: 0.05 }, { f: 617, a: 0.04 }, { f: 1231, a: 0.06 }, { f: 1502, a: 0.04 }, { f: 2060, a: 0.05 }];
const PULSES = [424, 1015, 1163, 1309, 1592, 1740, 2001]; // place changes: a short white pulse instead of a crossfade
export const camAt = (f) => {
  const S = shotAt(f), c = camFromKeys(CAMS[S.id], f, { creep: 0.0012, kicks: KICKS });
  c.flash = f >= 238 && f < 244 ? (1 - (f - 238) / 6) * 0.85 : 0;
  for (const p of PULSES) if (f >= p && f < p + 4) c.flash = 0.3 * (1 - (f - p) / 4);
  return c;
};

// ---------- lens ----------
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
const CINF = { 1: 0, 2: 0, 3: 12, 4: 14, 5: 0, 6: 12, 7: 0, 8: 13, 9: 11, 10: 7, 11: 5, 12: 0 };
export const dofAt = (f) => { const S = shotAt(f), C = camAt(f); return { focus: dist(C.pos, C.look), cinf: CINF[S.id] }; };

// ---------- world state ----------
export const worldAt = (f) => {
  const S = shotAt(f);
  return { id: S.id, seaShip: S.id === 7 ? [P.SEA[0], 0.1 * Math.sin(f / 30 * 1.6), shipZ(f)] : null, holdTop: S.id !== 8, puddle: clamp((f - 527) / 36) };
};

// ---------- actors (2D cards) ----------
const R = (T, who, o, pos, extra = {}) => ({ key: who + JSON.stringify(o), draw: (p) => T.romanFront(p, who, o), x: pos[0], y: pos[1], z: pos[2], ...extra });
const FOLK = ['calA', 'calB', 'calC', 'calD', 'calE', 'calF'];
export const actorsAt = (f, T) => {
  const S = shotAt(f), out = [], tint = S.light === 'golden' ? '#ffe2c8' : S.light === 'night' ? '#c9d6ff' : '#ffffff';
  const t = f / 30, W = P.WHARF;
  const blink = (s) => blinkAt(f, s);
  const worker = (i, pos, expr = 'neutral') => {
    const step = q((t * 1.6 + i * 0.13) % 1, 2);
    out.push(R(T, ['cutA', 'cutB', 'cutC'][i % 3], { seed: 10 + i, expr, step, blink: blink(10 + i), ...idle(f, i) }, pos, { tint }));
  };
  const haul = (n, spread = 1) => { // ice cutters hauling blocks from the pond edge to the ship
    for (let i = 0; i < n; i++) {
      const u = (t * 0.1 + i / n) % 1;
      worker(i, [lerp(W[0] + 7, W[0] - 4, u), 0, lerp(W[2] + 9, W[2] - 5, u) * spread + (1 - spread) * W[2]], 'grin');
    }
  };
  const tudor = (pos, expr, extra = {}) => out.push(R(T, 'tudor', { seed: 2, expr, blink: blink(2), L: 'hang', R: 'hang', ...idle(f, 2), ...extra }, pos, { tint }));
  switch (S.id) {
    case 1: {
      [[-2.0, 0.3], [2.4, -0.2]].forEach(([dx, dz], i) => out.push(R(T, ['cutA', 'cutB'][i], { seed: 40 + i, expr: 'grin', L: 'hang', R: 'hang', blink: blink(40 + i), ...idle(f, i) }, A(W, dx, 0, dz), { tint })));
      haul(4, 1);
      break;
    }
    case 2: {
      const C = P.CAL;
      for (let i = 0; i < 16; i++) {
        const x = C[0] + (((i * 37) % 70) / 10 - 3.5), z = C[2] - 14 + i * 1.7 + ((i * 7) % 5) * 0.2;
        out.push(R(T, FOLK[i % 6], { seed: 30 + i, expr: i % 2 ? 'pained' : 'dazed', L: 'hang', R: 'wave', wv: f * 0.45 + i, blink: blink(30 + i), ...idle(f, i) }, [x, 0, z], { tint }));
      }
      out.push(R(T, 'bishop', { seed: 5, expr: f < 324 ? 'neutral' : 'pained', L: 'hang', R: f >= 322 ? 'wave' : 'hang', wv: f * 0.4, blink: blink(5), ...idle(f, 5) }, A(C, -4.5, 2.0, 2.0), { tint, ground: 2.0 }));
      break;
    }
    case 3: {
      haul(3);
      tudor([W[0], 0, W[2]], f < 525 ? 'stern' : 'shock');
      break;
    }
    case 4: {
      haul(2);
      tudor([W[0] + (f < 595 ? -3 : f < 600 ? -1 : f < 612 ? 1 : f < 617 ? 3 : 5), 0, W[2] + 1.9], f < 615 ? 'nervous' : 'grin');
      break;
    }
    case 5: { haul(6); tudor([W[0] - 2.5, 0, W[2] + 1], 'smile'); break; }
    case 6: {
      const H = P.HOLD;
      [-0.5, 0.7].forEach((dz, i) => {
        const up = Math.sin(f * 0.33 + i * 1.6) > 0;
        out.push(R(T, 'sailA', { seed: 60 + i, expr: 'neutral', L: up ? 'lift' : 'hang', R: up ? 'hang' : 'lift', blink: blink(60 + i) }, [H[0] - 1.45, 0, H[2] + dz], { tint }));
      });
      break;
    }
    case 7: {
      const sz = shipZ(f), bob = 0.1 * Math.sin(t * 1.6);
      [[-0.8, -3], [1.0, 1.5], [-1.2, 6.5]].forEach(([lx, lz], i) =>
        out.push(R(T, 'sailA', { seed: 70 + i, expr: 'neutral', L: 'hang', R: 'hang', blink: blink(70 + i), ...idle(f, i) }, [P.SEA[0] + lx, 1.8 + bob, sz + lz], { tint, ground: 1.8 })));
      break;
    }
    case 8: {
      const H = P.HOLD, lost = f >= 1229;
      tudor(A(H, -0.1, 0, -1.4), !lost ? 'relief' : f < 1243 ? 'shock' : 'pained');
      out.push(R(T, 'sailA', { seed: 62, expr: lost ? 'dazed' : 'smile', L: 'hang', R: 'hang', blink: blink(62), ...idle(f, 3) }, A(H, -1.3, 0, -2.0), { tint }));
      break;
    }
    case 9: {
      const J = P.JACKET;
      out.push(R(T, 'kid', { seed: 80, expr: f < 1354 ? 'smile' : f < 1502 ? 'grin' : 'laugh', L: 'hang', R: 'hang', blink: blink(80), ...idle(f, 8) }, [J[0], 0, J[2]], { tint, s: 0.82 }));
      break;
    }
    case 10: {
      const C = P.CAL, ex = ['smile', 'grin', 'relief', 'smile_closed', 'laugh', 'smile'];
      [[-1.3, 5.1], [0.2, 4.9], [1.5, 5.2], [-1.1, 7.0], [0.4, 7.2], [1.6, 6.9]].forEach(([dx, dz], i) =>
        out.push(R(T, FOLK[i], { seed: 90 + i, expr: ex[i], L: 'hang', R: i % 2 ? 'up' : 'hang', blink: blink(90 + i), ...idle(f, i) }, A(C, dx, 0, dz), { tint })));
      break;
    }
    case 12: {
      const Wd = P.WALDEN;
      out.push(R(T, 'thoreau', { seed: 95, expr: f < 2060 ? 'smile_closed' : 'smile', L: 'hang', R: 'hang', blink: blink(95), ...idle(f, 9) }, A(Wd, 2.5, 0, -2.0), { tint }));
      for (let i = 0; i < 5; i++) worker(i, A(Wd, -7 + i * 2.2, 0, 8 + ((i * 7) % 5) * 0.6));
      break;
    }
  }
  return out;
};

// ---------- 2D effects ----------
const FX = (key, draw, pos, s, extra = {}) => ({ key, draw, x: pos[0], y: pos[1], z: pos[2], s, blob: false, shadow: false, order: 5, ...extra });
export const fxAt = (f, T) => {
  const S = shotAt(f), out = [], W = P.WHARF;
  if (S.id === 3 && f >= 527) {
    const k = clamp((f - 527) / 36), s = 0.6 + 1.4 * M.smooth(k);
    out.push(FX('puddle' + q(k, 1), (p) => { p.ell(300, 700, 280 * 0.5, 80 * 0.5, '#6f97c6', 0); p.ell(250, 690, 90, 20, '#a9c9ea', 0); }, [W[0], 0.1, W[2] + 0.7], s));
    if (f < 540) { const k2 = q((f - 527) / 13, 2); out.push(FX('burstm' + k2, (p) => { p.g.translate(0, 0); T.fxBurst(p, k2, '#cfe9ff'); }, [W[0] + 0.5, 1.4, W[2] - 0.1], 1.1)); }
  }
  if (S.id === 4 && f >= 617 && f < 630) { const k = q((f - 617) / 13, 2); out.push(FX('bursts' + k, (p) => T.fxBurst(p, k, '#ffe9a0'), [W[0] + 5, 1.3, W[2] - 0.2], 1.3)); }
  if (S.id === 8 && f >= 1231 && f < 1250) { const k = q((f - 1231) / 19, 2), H = P.HOLD; out.push(FX('splashh' + k, (p) => { p.g.translate(0, 130); p.g.scale(0.75, 0.75); T.fxSplash(p, k); }, A(H, 0.2, 0.05, -0.6), 1.4)); }
  if (S.id === 9 && f >= 1352 && f < 1502) {
    const J = P.JACKET;
    for (let i = 0; i < 6; i++) { const u = q(((f - 1352) * 0.02 + i / 6) % 1, 2), a = i * 1.05;
      out.push(FX('puff' + u, (p) => T.fxPuff(p, u), [J[0] + 0.55 * Math.cos(a), 1.0 + 0.3 * Math.sin(a * 2), J[2] + 0.25 * Math.sin(a)], 0.4)); }
  }
  if (S.light === 'day') { const C = camAt(f); for (let i = 0; i < 9; i++) { const a = f * 0.02 + i * 2.1, d = 2.2 + (i % 4) * 0.7;
    const x = C.pos[0] + (C.look[0] - C.pos[0]) * d / 4 + Math.sin(a) * 0.9, y = C.pos[1] + 0.2 + (i % 3) * 0.35 + Math.sin(a * 1.3) * 0.15, z = C.pos[2] + (C.look[2] - C.pos[2]) * d / 4 + Math.cos(a * 0.8) * 0.9;
    out.push(FX('mote' + (i % 3), (p) => p.ell(300, 500, 30, 30, 'rgba(255,243,220,0.55)', 0), [x, y, z], 0.18)); } }
  if (S.id === 10) { const u = q((f * 0.03) % 1, 2), C = P.CAL; out.push(FX('stars' + u, (p) => T.fxStars(p, u), A(C, 0, 1.6, 6), 0.9)); }
  return out;
};
